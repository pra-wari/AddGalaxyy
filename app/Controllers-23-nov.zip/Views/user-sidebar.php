<?php $user_id = session()->get('id');  ?>
<div class="col-md-3 col-sm-4 mb-xs-30 mobile-spacing">
    <div class="sidebar-block gray-box">
        <div class="sidebar-box listing-box cat1 mb-40">
            <span class="opener plus"></span>
            <div class="main_title sidebar-title">
                <h3><span>Dashboard</span></h3>
            </div>
            <div class="sidebar-contant">
                <!-- subcategory list start -->
                <div class="panel-group" id="adminaccordion">
                    <div class="panel panel-default ">
                        <div class="panel-heading  <?php if(!$currentpage){ echo 'selected'; }?>">
                            <h4 class="panel-title">
                                <a href="#2">
                                    <a class="cat_list" href="<?php echo base_url('/dashboard');?>">
                                        <span style="padding-left:10px;">My Ads</span>
                                    </a>
                                    <i class="fa fa-caret-right"></i>
                                </a>
                            </h4>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading <?php if($currentpage=='updatepassword'){ echo 'selected'; }?>">
                            <h4 class="panel-title">
                                <a href="#2">
                                    <a class="cat_list"
                                        href="<?php echo base_url('/users/updatepassword/'.$user_id);?>">
                                        <span style="padding-left:10px;">Update Password</span>
                                    </a>
                                    <i class="fa fa-caret-right"></i>
                                </a>
                            </h4>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading <?php if($currentpage=='editprofile'){ echo 'selected'; }?>">
                            <h4 class="panel-title">
                                <a href="#2">
                                    <a class="cat_list" href="<?php echo base_url('/users/editprofile/'.$user_id);?>">
                                        <span style="padding-left:10px;">Edit Profile</span>
                                    </a>
                                    <i class="fa fa-caret-right"></i>
                                </a>
                            </h4>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a href="#2">
                                    <a class="cat_list" href="<?php echo base_url('/users/messages/'.$user_id);?>">
                                        <span style="padding-left:10px;">Messages</span>
                                    </a>
                                    <i class="fa fa-caret-right"></i>
                                </a>
                            </h4>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a href="#2">
                                    <a class="cat_list" href="<?php echo base_url('/users/invoices/'.$user_id);?>">
                                        <span style="padding-left:10px;">Invoice/bill</span>
                                    </a>
                                    <i class="fa fa-caret-right"></i>
                                </a>
                            </h4>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a href="#2">
                                    <a class="cat_list" href="<?php echo base_url('/users/logout/');?>">
                                        <span style="padding-left:10px;">Logout</span>
                                    </a>
                                    <i class="fa fa-caret-right"></i>
                                </a>
                            </h4>
                        </div>
                    </div>


                </div>
                <!-- subcategory list end -->

            </div>
        </div>
    </div>
</div>