<?php namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model{
  protected $table = 'users';
  protected $allowedFields = ['firstname','lastname', 'username', 'email', 'password', 'date','mobile','modified_date','valid','deleted'];
  protected $beforeInsert = ['beforeInsert'];
  protected $beforeUpdate = ['beforeUpdate'];

  protected function beforeInsert(array $data){
    //$data = $this->passwordHash($data);
    $data['data']['date'] = date('Y-m-d H:i:s');
    $data['data']['modified_date'] = date('Y-m-d H:i:s');
    $data['data']['date'] = 'usertype';
    return $data;
  }

  protected function beforeUpdate(array $data){
    //$data = $this->passwordHash($data);
    $data['data']['modified_date'] = date('Y-m-d H:i:s');
    return $data;
  }

  protected function passwordHash(array $data){
    if(isset($data['data']['password']))
      $data['data']['password'] = password_hash($data['data']['password'], PASSWORD_DEFAULT);

    return $data;
  }


}