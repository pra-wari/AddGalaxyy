<div class="search-bar mb-30 center-xs">
    <div class="container">
      <form id="search-bar-box" action="<?php echo base_url();?>" method="post">

          <div class="row">
          <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <div class="select-dropdown select-dropdown1">
              <fieldset>
              <select id="region" name="region" class="form-control" required="required" data-error="Select Region">
                    <option>Select Region</option>
                                       <option value="1" i="">Andaman and Nicobar Islands</option>
                                    <option value="2" i="">Andhra Pradesh'</option>
                                    <option value="3" i="">Arunachal Pradesh</option>
                                    <option value="4" i="">Assam</option>
                                    <option value="5" i="">Bihar</option>
                                    <option value="6" i="">Chandigarh</option>
                                    <option value="7" i="">Chhattisgarh</option>
                                    <option value="8" i="">Dadra and Nagar Haveli</option>
                                    <option value="9" i="">Daman and Diu</option>
                                    <option value="10" selected="" i="">Delhi</option>
                                    <option value="11" i="">Goa</option>
                                    <option value="12" i="">Gujarat</option>
                                    <option value="13" i="">Haryana</option>
                                    <option value="14" i="">Himachal Pradesh</option>
                                    <option value="15" i="">Jammu and Kashmir</option>
                                    <option value="16" i="">Jharkhand</option>
                                    <option value="17" i="">Karnataka</option>
                                    <option value="18" i="">Kenmore</option>
                                    <option value="19" i="">Kerala</option>
                                    <option value="20" i="">Lakshadweep</option>
                                    <option value="21" i="">Madhya Pradesh</option>
                                    <option value="22" i="">Maharashtra</option>
                                    <option value="23" i="">Manipur</option>
                                    <option value="24" i="">Meghalaya</option>
                                    <option value="25" i="">Mizoram</option>
                                    <option value="26" i="">Nagaland</option>
                                    <option value="27" i="">Narora</option>
                                    <option value="28" i="">Natwar</option>
                                    <option value="29" i="">Odisha</option>
                                    <option value="30" i="">Paschim Medinipur</option>
                                    <option value="31" i="">Pondicherry</option>
                                    <option value="32" i="">Punjab</option>
                                    <option value="33" i="">Rajasthan</option>
                                    <option value="34" i="">Sikkim</option>
                                    <option value="35" i="">Tamil Nadu</option>
                                    <option value="36" i="">Telangana</option>
                                    <option value="37" i="">Tripura</option>
                                    <option value="38" i="">Uttar Pradesh</option>
                                    <option value="39" i="">Uttarakhand</option>
                                    <option value="40" i="">Vaishali</option>
                                    <option value="41" i="">West Bengal</option>
                                </select>                                
              </fieldset>
              <div class="help-block with-errors"></div>
            </div>
          </div>
          <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
            <div class="select-dropdown select-dropdown2">
              <fieldset>
                <select name="category" class="countr option-drop form-control select2-hidden-accessible" required="required" tabindex="-1" aria-hidden="true">
                   <option value="all">All Category</option>
                  
                  <option value="2">Vehicle</option>
                  
                  <option value="3">Real Estate </option>
                  
                  <option value="4">Pets </option>
                  
                  <option value="5">Jobs </option>
                  
                  <option value="6">Personals </option>
                  
                  <option value="7">Miscellaneous</option>
                  
                  <option value="8">Services </option>
                  
                  <option value="9">Electronics</option>
                                    
                </select>
                <!--<span class="select2 select2-container select2-container--default" dir="ltr" style="width: 241px;">
                  <span class="selection">
                    <span class="select2-selection select2-selection--single" role="combobox" aria-autocomplete="list" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-category-f5-container">
                      <span class="select2-selection__rendered" id="select2-category-f5-container" title="All Category">All Category</span>
                      <span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span>
                    </span>
                  </span>
                  <span class="dropdown-wrapper" aria-hidden="true"></span>
                </span>-->
              </fieldset>
            </div>
          </div>
        <form method="post" action="<?php echo base_url('search');?>">
          <div class="col-lg-3 col-md-3 col-sm-8 col-xs-12 col-mb-12">
            <div class="key-word">
              <input type="text" name="keyword" required="required" value="" placeholder="Enter Keywords here ...">
            </div>
          </div>
          <div class="col-lg-2 col-md-3 col-sm-4 col-xs-12 col-mb-12 text-right mobile-side" style="padding-right: 40px;">
            <button type="submit" class="btn-color btn big-width"> <i class="fa fa-search"></i>Search</button> 
          </div>
        </form>
        </div>
      </form>
    </div>
  </div>
  