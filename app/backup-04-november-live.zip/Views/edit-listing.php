<?php echo view('header'); 
 //print_r($listing);
?>
<div class="search-bar center-xs">
    <div class="container-fluid">
        <div class="bread-crumb center-xs">
        </div>
    </div>
</div>
<section class="pb-95" id="desktop-view">
    <div class="container-fluid">
        <div class="row">
        <?php echo view('admin-sidebar');?>
            <div class="col-md-6 col-sm-8" id="product-de">
                <div class="product-listing1">
                    <div class="row" id="filterResult1">
                        <div class="container1">
                            <div class="col-md-12">
                                <div class="col-md-12">
                                    <h1>Edit Listing</h1>
                                    <p class="lead"></p>
                                    <form name="ad-form" id="ad-form" method="post" action="" role="form"
                                        enctype="multipart/form-data" onsubmit="return checkTitle();">
                                        <div class="messages"></div>
                                        <input type="hidden" name="tid" id="tid" readonly="">
                                        <div class="controls">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="form_name">Category *</label>
                                                        <select id="category" name="category" class="form-control"
                                                            required="required" data-error="Category is required."
                                                            onchange="getCat(this.value);getPackage();">
                                                            <option value="">Select Category</option>
                                                            <option value="2">Vehicle</option>
                                                            <option value="3">Real Estate </option>
                                                            <option value="4">Pets </option>
                                                            <option value="5">Jobs </option>
                                                            <option value="6">Personals </option>
                                                            <option value="7">Miscellaneous</option>
                                                            <option value="8">Services </option>
                                                            <option value="9">Electronics</option>
                                                        </select>
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="form_name">Sub Category *</label>
                                                        <select id="subcategory" name="subcategory" class="form-control"
                                                            required="required" data-error="Sub Category is required."
                                                            onchange="getPackage();">
                                                            <option value="">Select Subcategory</option>
                                                        </select>
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="form_email">Title *</label>
                                                        <input id="title" type="text" maxlength="65" name="title"
                                                            class="form-control" placeholder="Please enter a title *"
                                                            required="required"
                                                            data-error="Title should be atleast 10 chars long"
                                                            value="<?php echo $listing[0]['title'];?>">
                                                        <div class="help-block with-errors" id="titleerrorid"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="form_email">Description *</label>
                                                        <textarea rows="10" col="200" id="desc" name="desc"
                                                            class="form-control"
                                                            placeholder="Please enter the description of your add *"
                                                            required="required"
                                                            data-error="Description should be atleast 100 chars long"><?php echo $listing[0]['description'];?></textarea>
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- RealEstate Category start  -->
                                            <div id="realestate" style="display:none">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="form_email">Property for *</label>
                                                            <input id="property_for" type="radio" name="property_for"
                                                                value="sell">Sell
                                                            <input id="property_for" type="radio" name="property_for"
                                                                value="rent">Rent
                                                            <input id="property_for" type="radio" name="property_for"
                                                                value="pg">PG
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="form_email">You are a *</label>
                                                            <input id="property_for" type="radio" name="you_are_a"
                                                                value="owner">Owner
                                                            <input id="property_for" type="radio" name="you_are_a"
                                                                value="broker">Broker
                                                            <input id="property_for" type="radio" name="you_are_a"
                                                                value="builder">Builder
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="form_email">Property Type *</label>
                                                            <select name="property_type" class="form-control"
                                                                id="property">
                                                                <option value="">Select Property Type</option>
                                                                <optgroup label="Residential">
                                                                    <option value="house">House</option>
                                                                    <option value="multistory apartment">Multistory
                                                                        Apartment</option>
                                                                    <option value="builder floor">Builder Floor</option>
                                                                    <option value="plot">Plot</option>
                                                                    <option value="villa">Villa</option>
                                                                    <option value="penta house">Penta House</option>
                                                                    <option value="studio apartment">Studio Apartment
                                                                    </option>
                                                                </optgroup>
                                                                <optgroup label="Commercial">
                                                                    <option value="commercial office space">Commercial
                                                                        Office Space</option>
                                                                    <option value="IT park office">IT Park Office
                                                                    </option>
                                                                    <option value="commercial shop"> Commercial Shop
                                                                    </option>
                                                                    <option value="commercial showroom">Commercial
                                                                        Showroom</option>
                                                                    <option value="commercial land">Commercial Land
                                                                    </option>
                                                                    <option value="warehouse/Godown">Warehouse/Godown
                                                                    </option>
                                                                    <option value="industrial land">Industrial Land
                                                                    </option>
                                                                    <option value="industrial building">Industrial
                                                                        Building</option>
                                                                    <option value="industrial shed">Industrial Shed
                                                                    </option>
                                                                </optgroup>
                                                                <optgroup label="Agriculture">
                                                                    <option value="agricultural land">Agricultural Land
                                                                    </option>
                                                                    <option value="farm house">Farm House</option>
                                                                </optgroup>
                                                            </select>
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--<div class="row">-->
                                                <!--    <div class="col-md-12">-->
                                                <!--        <div class="form-group">-->
                                                <!--<input id="property_feature" type="text" name="property_feature" class="form-control"placeholder="Property Feature" >                                        -->
                                                <!--            <div class="help-block with-errors"></div>-->
                                                <!--        </div>-->
                                                <!--    </div>-->
                                                <!--</div>-->
                                                <label for="form_email">Property feature *</label>
                                                <!------features of house----All Features--->
                                                <div class="row property-feat">
                                                    <div class="col-md-4" style="display:none" id="bedroom">
                                                        <div class="form-group">
                                                            <label for="bedroom">Bedroom *</label>
                                                            <select id="bedroom" name="bedroom" class="form-control">
                                                                <option value="">Select Balcony</option>
                                                                <option value="0">None</option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                                <option value="5">5</option>
                                                            </select>
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4" style="display:none" id="bathroom">
                                                        <div class="form-group">
                                                            <label for="bathroom">Bathroom *</label>
                                                            <select id="bathroom" name="bathroom" class="form-control">
                                                                <option value="">Select Balcony</option>
                                                                <option value="0">None</option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                                <option value="5">5</option>
                                                            </select>
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4" style="display:none" id="balcony">
                                                        <div class="form-group">
                                                            <label for="balcony">Balcony *</label>
                                                            <select id="balcony" name="balcony" class="form-control">
                                                                <option value="">Select Balcony</option>
                                                                <option value="0">None</option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                                <option value="5">5</option>
                                                            </select>
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4" style="display:none" id="kitchen">
                                                        <div class="form-group">
                                                            <label for="kitchen">Kitchen *</label>
                                                            <select id="kitchen" name="kitchen" class="form-control">
                                                                <option value="">Select Kitchen</option>
                                                                <option value="0">None</option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                                <option value="5">5</option>
                                                            </select>
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4" style="display:none" id="tfloor">
                                                        <div class="form-group">
                                                            <label for="tfloor">Total Floor *</label>
                                                            <select id="tfloor" name="tfloor" class="form-control">
                                                                <option value="">Select Total Floor</option>
                                                                <option value="0">None</option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                                <option value="5">5</option>
                                                                <option value="6">6</option>
                                                                <option value="7">7</option>
                                                                <option value="8">8</option>
                                                                <option value="9">9</option>
                                                                <option value="10">10</option>
                                                                <option value="11">11</option>
                                                                <option value="12">12</option>
                                                                <option value="13">13</option>
                                                                <option value="14">14</option>
                                                                <option value="15">15</option>
                                                                <option value="16">16</option>
                                                                <option value="17">17</option>
                                                                <option value="18">18</option>
                                                                <option value="19">19</option>
                                                                <option value="20">20</option>
                                                                <option value="21">21</option>
                                                                <option value="22">22</option>
                                                                <option value="23">23</option>
                                                                <option value="24">24</option>
                                                                <option value="25">25</option>
                                                            </select>
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4" style="display:none" id="floor">
                                                        <div class="form-group">
                                                            <label for="floor">Floor *</label>
                                                            <select id="floor" name="floor" class="form-control">
                                                                <option value="">Select Floor</option>
                                                                <option value="0">None</option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                                <option value="5">5</option>
                                                                <option value="6">6</option>
                                                                <option value="7">7</option>
                                                                <option value="8">8</option>
                                                                <option value="9">9</option>
                                                                <option value="10">10</option>
                                                                <option value="11">11</option>
                                                                <option value="12">12</option>
                                                                <option value="13">13</option>
                                                                <option value="14">14</option>
                                                                <option value="15">15</option>
                                                                <option value="16">16</option>
                                                                <option value="17">17</option>
                                                                <option value="18">18</option>
                                                                <option value="19">19</option>
                                                                <option value="20">20</option>
                                                                <option value="21">21</option>
                                                                <option value="22">22</option>
                                                                <option value="23">23</option>
                                                                <option value="24">24</option>
                                                                <option value="25">25</option>
                                                            </select>
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4" style="display:none" id="furnished">
                                                        <div class="form-group">
                                                            <label for="furnished">Furnished *</label>
                                                            <select id="furnished" name="furnished"
                                                                class="form-control">
                                                                <option value="">Select Option</option>
                                                                <option value="yes">Yes</option>
                                                                <option value="no">No</option>
                                                            </select>
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!--common fields of real estate-->
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="form_email">Area *</label>
                                                            <input type="text" name="area" id="area" style="width:50%;">
                                                            <select class="static-value-unit" name="area_unit">
                                                                <option value="unit">Unit</option>
                                                                <option value="square-feet">Square feet</option>
                                                                <option value="hectare">Hectare</option>
                                                            </select>
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="form_email">Transaction Type *</label>
                                                            <input type="radio" name="transaction_type" value="new">New
                                                            <input type="radio" name="transaction_type"
                                                                value="resale">Resale
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="form_email">Transaction Status *</label>
                                                            <input type="radio" name="transaction_status"
                                                                value="under-construction">Under Construction
                                                            <input type="radio" name="transaction_status"
                                                                value="ready-to-move">Ready to Move
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- RealEstate Category End -->


                                            <!-- Action, Condition, Posted row Start -->
                                            <div id="actionConditionPosted">
                                                <div class="row" style="display:block" id="posted">
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label for="form_email">You are a *</label>
                                                            <input id="posted_by" type="radio" name="posted_by"
                                                                value="individual"> Individual
                                                            <input id="posted_by" type="radio" name="posted_by"
                                                                value="dealer"><span id="dealer"> Dealer</span>
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4" style="display:block" id="action">
                                                        <div class="form-group">
                                                            <label for="form_email">Action *</label>
                                                            <input id="action" type="radio" name="action" value="offer">
                                                            Offer
                                                            <input id="action" type="radio" name="action"
                                                                value="wanted"> Wanted
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4" style="display:block" id="condition">
                                                        <div class="form-group">
                                                            <label for="form_conditionl">Condition *</label>
                                                            <input id="condition" type="radio" name="condition"
                                                                value="new"> New
                                                            <input id="condition" type="radio" name="condition"
                                                                value="used"> Used
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Action, Condition, Posted row end -->
                                            <!-- Vehicle Category Start -->
                                            <div class="row">
                                                <div class="col-md-4" style="display:none" id="fuel_type">
                                                    <div class="form-group">
                                                        <label for="fuel type">Fuel Type *</label>
                                                        <select id="fuel_type" name="vehicle_fuel_type"
                                                            class="form-control">
                                                            <option value="">Select Fuel Type</option>
                                                            <option value="Petrol">Petrol</option>
                                                            <option value="Deisel">Deisel</option>
                                                            <option value="CNG">CNG</option>
                                                            <option value="LPG">LPG</option>
                                                        </select>
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                                <div class="col-md-4" style="display:none" id="vehicle_brand">
                                                    <div class="form-group">
                                                        <label for="form_email">Brand *</label>
                                                        <!--                                            <input id="vehicle_brand" type="text" name="vehicle_brand" class="form-control" placeholder="Brand Name">-->
                                                        <select id="vehicle_brand" name="vehicle_brand"
                                                            class="form-control">
                                                            <option value="">Select Brand</option>
                                                            <option value="KTM Duke">KTM Duke</option>
                                                            <option value="Royel Enfield">Royel Enfield</option>
                                                            <option value="Thunderbird">Thunderbird</option>
                                                            <option value="Pulsar220F">Pulsar220F</option>
                                                            <option value="Bajaj Pulsar 150">Bajaj Pulsar 150</option>
                                                            <option value="Bajaj Pulsar 150 DTS i">Bajaj Pulsar 150 DTS
                                                                i</option>
                                                            <option value="Bajaj Pulsar NS160">Bajaj Pulsar NS160
                                                            </option>
                                                            <option value="Bajaj Pulsar 180F">Bajaj Pulsar 180F</option>
                                                            <option value="Bajaj Pulsar 180">Bajaj Pulsar 180</option>
                                                            <option value="Bajaj Pulsar 200">Bajaj Pulsar 200</option>
                                                            <option value="Bajaj Pulsar 200">Bajaj Pulsar 200</option>
                                                            <option value="Bajaj Pulsar NS200">Bajaj Pulsar NS200
                                                            </option>
                                                            <option value="Bajaj Pulsar RS 200">Bajaj Pulsar RS 200
                                                            </option>
                                                            <option value="Bajaj Pulsar 200F">Bajaj Pulsar 200F</option>
                                                            <option value="Bajaj CT100">Bajaj CT100</option>
                                                            <option value="Bajaj Platina110">Bajaj Platina110</option>
                                                            <option value="Bajaj Dominar 400">Bajaj Dominar 400</option>
                                                            <option value="Bajaj Discover 125">Bajaj Discover 125
                                                            </option>
                                                            <option value="Bajaj Avenger Street 180">Bajaj Avenger
                                                                Street 180</option>
                                                            <option value="Bajaj Avenger Street 220">Bajaj Avenger
                                                                Street 220</option>
                                                            <option value="Bajaj Avenger Cruise 220">Bajaj Avenger
                                                                Cruise 220</option>
                                                            <option value="Bajaj Discover 110">Bajaj Discover 110
                                                            </option>
                                                            <option value="Bajaj V15">Bajaj V15</option>
                                                            <option value="TVS Jupiter">TVS Jupiter</option>
                                                            <option value="TVS NTORO ">TVS NTORO </option>
                                                            <option value="TVS Apache">TVS Apache</option>
                                                            <option value="Hero CD100">Hero CD100</option>
                                                            <option value="Hero Glamour">Hero Glamour</option>
                                                            <option value="CB Shine">CB Shine</option>
                                                            <option value="CB Unicorn">CB Unicorn</option>
                                                            <option value="Honda Dio">Honda Dio</option>
                                                            <option value="Activa">Activa</option>
                                                            <option value="Royal Enfield Classic 350">Royal Enfield
                                                                Classic 350</option>
                                                            <option value="Suzuki Gixxer">Suzuki Gixxer</option>
                                                            <option value="Suzuki Access 125">Suzuki Access 125</option>
                                                            <option value="FZS">FZS</option>
                                                            <option value="Kawasaki Ninja">Kawasaki Ninja</option>
                                                            <option value="BMW">BMW</option>
                                                            <option value="Maruti">Maruti</option>
                                                            <option value="BMW">BMW</option>
                                                            <option value="SKODA">SKODA</option>
                                                            <option value="XYLO">XYLO</option>
                                                        </select>
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                            </div>

                                            <!-- Vehicle Category End -->
                                            <!-- Electronics Category Start -->
                                            <div id="electronics" style="display:none">
                                                <div class="row">
                                                    <div class="col-md-4" style="display:block" id="vehicle_brand">
                                                        <div class="form-group">
                                                            <label for="form_brand">Brand *</label>
                                                            <input id="brand" type="text" name="brand"
                                                                class="form-control" placeholder="Brand Name">
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4" style="display:block" id="ram">
                                                        <div class="form-group">
                                                            <label for="ram">Ram *</label>
                                                            <select id="ram" name="ram" class="form-control">
                                                                <option value="">Select Ram</option>
                                                                <option value="1">1GB</option>
                                                                <option value="2">2GB</option>
                                                                <option value="3">3GB</option>
                                                                <option value="4">4GB</option>
                                                                <option value="5">5GB</option>
                                                            </select>
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4" style="display:block" id="screen_type">
                                                        <div class="form-group">
                                                            <label for="screen_type">Screen Type *</label>
                                                            <select id="screen_type" name="screen_type"
                                                                class="form-control">
                                                                <option value="">Select Screen Type</option>
                                                                <option value="LCD">LCD</option>
                                                                <option value="LED">LED</option>
                                                            </select>
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4" style="display:block" id="screen_size">
                                                        <div class="form-group">
                                                            <label for="screen_size">Screen Size (In Inches)*</label>
                                                            <input id="screen_size" type="text" name="screen_size"
                                                                class="form-control" placeholder="Screen Size">
                                                            <!--<select id="screen_size" name="screen_size" class="form-control">
                                                <option value="">Select Screen Size</option>
                                                <option value="3">3 Inches</option>
                                                <option value="3.5">3.5 Inches</option>
                                                <option value="4">4 Inches</option>
                                                <option value="4.5">4.5 Inches</option>
                                                <option value="5">5 Inches</option>
                                                <option value="5.5">5.5 Inches</option>
                                                <option value="6">6 Inches</option>
                                                <option value="6.5">6.5 Inches</option>
                                                <option value="7">7 Inches</option>
                                                <option value="7.5">7.5 Inches</option>
                                                <option value="8">8 Inches</option>
                                                <option value="8.5">8.5 Inches</option>
                                                <option value="9">9 Inches</option>
                                                <option value="9.5">9.5 Inches</option>
                                                <option value="10">10 Inches</option>
                                            </select>-->
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                            <!-- Electronics Category End -->
                                            <!-- JObs Category End -->
                                            <div id="jobs" style="display:none">
                                                <div class="row">
                                                    <div class="col-md-4" style="display:block" id="exp">
                                                        <div class="form-group">
                                                            <label for="form_brand">Experience (In Years) *</label>
                                                            <input id="exp" type="number" name="job_exp"
                                                                class="form-control" placeholder="Experience in Years">
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4" style="display:block" id="job_type">
                                                        <div class="form-group">
                                                            <label for="job type">Job Type *</label>
                                                            <select id="job_type" name="job_type" class="form-control">
                                                                <option value="">Select Job Type</option>
                                                                <option value="part time">Part Time Job</option>
                                                                <option value="full time">Full Time Job</option>
                                                                <option value="work from home">Work From Home</option>
                                                            </select>
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- JObs Category End -->

                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="form_email" id="priceLabel">Price *</label>

                                                        <input type="text" value="" id="price" name="price"
                                                            class="form-control" placeholder="0 *" required="required"
                                                            data-error="Price should be greater than 0">
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="form_email">Country *</label>
                                                        <select id="country" name="country" class="form-control"
                                                            required="required" data-error="Select Country"
                                                            onchange="getCon(this.value);getPackage();">
                                                            <option value="">Select Country</option>
                                                            <option value="2">Albania</option>
                                                            <option value="3">Algeria</option>
                                                            <option value="4">American Samoa</option>
                                                            <option value="5">Andorra</option>
                                                            <option value="6">Angola</option>
                                                            <option value="7">Anguilla</option>
                                                            <option value="8">Antarctica</option>
                                                            <option value="9">Antigua And Barbuda</option>
                                                            <option value="10">Argentina</option>
                                                            <option value="12">Aruba</option>
                                                            <option value="13">Australia</option>
                                                            <option value="14">Austria</option>
                                                            <option value="15">Azerbaijan</option>
                                                            <option value="16">Bahamas The</option>
                                                            <option value="17">Bahrain</option>
                                                            <option value="18">Bangladesh</option>
                                                            <option value="19">Barbados</option>
                                                            <option value="20">Belarus</option>
                                                            <option value="21">Belgium</option>
                                                            <option value="22">Belize</option>
                                                            <option value="23">Benin</option>
                                                            <option value="24">Bermuda</option>
                                                            <option value="25">Bhutan</option>
                                                            <option value="26">Bolivia</option>
                                                            <option value="27">Bosnia and Herzegovina</option>
                                                            <option value="28">Botswana</option>
                                                            <option value="29">Bouvet Island</option>
                                                            <option value="30">Brazil</option>
                                                            <option value="31">British Indian Ocean Territory</option>
                                                            <option value="32">Brunei</option>
                                                            <option value="33">Bulgaria</option>
                                                            <option value="34">Burkina Faso</option>
                                                            <option value="35">Burundi</option>
                                                            <option value="36">Cambodia</option>
                                                            <option value="37">Cameroon</option>
                                                            <option value="38">Canada</option>
                                                            <option value="39">Cape Verde</option>
                                                            <option value="40">Cayman Islands</option>
                                                            <option value="41">Central African Republic</option>
                                                            <option value="42">Chad</option>
                                                            <option value="43">Chile</option>
                                                            <option value="44">China</option>
                                                            <option value="45">Christmas Island</option>
                                                            <option value="46">Cocos (Keeling) Islands</option>
                                                            <option value="47">Colombia</option>
                                                            <option value="48">Comoros</option>
                                                            <option value="49">Republic Of The Congo</option>
                                                            <option value="50">Democratic Republic Of The Congo</option>
                                                            <option value="51">Cook Islands</option>
                                                            <option value="52">Costa Rica</option>
                                                            <option value="53">Cote D'Ivoire (Ivory Coast)</option>
                                                            <option value="54">Croatia (Hrvatska)</option>
                                                            <option value="55">Cuba</option>
                                                            <option value="56">Cyprus</option>
                                                            <option value="57">Czech Republic</option>
                                                            <option value="58">Denmark</option>
                                                            <option value="59">Djibouti</option>
                                                            <option value="60">Dominica</option>
                                                            <option value="61">Dominican Republic</option>
                                                            <option value="62">East Timor</option>
                                                            <option value="63">Ecuador</option>
                                                            <option value="64">Egypt</option>
                                                            <option value="65">El Salvador</option>
                                                            <option value="66">Equatorial Guinea</option>
                                                            <option value="67">Eritrea</option>
                                                            <option value="68">Estonia</option>
                                                            <option value="69">Ethiopia</option>
                                                            <option value="70">External Territories of Australia
                                                            </option>
                                                            <option value="71">Falkland Islands</option>
                                                            <option value="72">Faroe Islands</option>
                                                            <option value="73">Fiji Islands</option>
                                                            <option value="74">Finland</option>
                                                            <option value="75">France</option>
                                                            <option value="76">French Guiana</option>
                                                            <option value="77">French Polynesia</option>
                                                            <option value="78">French Southern Territories</option>
                                                            <option value="79">Gabon</option>
                                                            <option value="80">Gambia The</option>
                                                            <option value="81">Georgia</option>
                                                            <option value="82">Germany</option>
                                                            <option value="83">Ghana</option>
                                                            <option value="84">Gibraltar</option>
                                                            <option value="85">Greece</option>
                                                            <option value="86">Greenland</option>
                                                            <option value="87">Grenada</option>
                                                            <option value="88">Guadeloupe</option>
                                                            <option value="89">Guam</option>
                                                            <option value="90">Guatemala</option>
                                                            <option value="91">Guernsey and Alderney</option>
                                                            <option value="92">Guinea</option>
                                                            <option value="93">Guinea-Bissau</option>
                                                            <option value="94">Guyana</option>
                                                            <option value="95">Haiti</option>
                                                            <option value="96">Heard and McDonald Islands</option>
                                                            <option value="97">Honduras</option>
                                                            <option value="98">Hong Kong S.A.R.</option>
                                                            <option value="99">Hungary</option>
                                                            <option value="100">Iceland</option>
                                                            <option value="101">India</option>
                                                            <option value="102">Indonesia</option>
                                                            <option value="103">Iran</option>
                                                            <option value="104">Iraq</option>
                                                            <option value="105">Ireland</option>
                                                            <option value="106">Israel</option>
                                                            <option value="107">Italy</option>
                                                            <option value="108">Jamaica</option>
                                                            <option value="109">Japan</option>
                                                            <option value="110">Jersey</option>
                                                            <option value="111">Jordan</option>
                                                            <option value="112">Kazakhstan</option>
                                                            <option value="113">Kenya</option>
                                                            <option value="114">Kiribati</option>
                                                            <option value="115">Korea North</option>
                                                            <option value="116">Korea South</option>
                                                            <option value="117">Kuwait</option>
                                                            <option value="118">Kyrgyzstan</option>
                                                            <option value="119">Laos</option>
                                                            <option value="120">Latvia</option>
                                                            <option value="121">Lebanon</option>
                                                            <option value="122">Lesotho</option>
                                                            <option value="123">Liberia</option>
                                                            <option value="124">Libya</option>
                                                            <option value="125">Liechtenstein</option>
                                                            <option value="126">Lithuania</option>
                                                            <option value="127">Luxembourg</option>
                                                            <option value="128">Macau S.A.R.</option>
                                                            <option value="129">Macedonia</option>
                                                            <option value="130">Madagascar</option>
                                                            <option value="131">Malawi</option>
                                                            <option value="132">Malaysia</option>
                                                            <option value="133">Maldives</option>
                                                            <option value="134">Mali</option>
                                                            <option value="135">Malta</option>
                                                            <option value="136">Man (Isle of)</option>
                                                            <option value="137">Marshall Islands</option>
                                                            <option value="138">Martinique</option>
                                                            <option value="139">Mauritania</option>
                                                            <option value="140">Mauritius</option>
                                                            <option value="141">Mayotte</option>
                                                            <option value="142">Mexico</option>
                                                            <option value="143">Micronesia</option>
                                                            <option value="144">Moldova</option>
                                                            <option value="145">Monaco</option>
                                                            <option value="146">Mongolia</option>
                                                            <option value="147">Montserrat</option>
                                                            <option value="148">Morocco</option>
                                                            <option value="149">Mozambique</option>
                                                            <option value="150">Myanmar</option>
                                                            <option value="151">Namibia</option>
                                                            <option value="152">Nauru</option>
                                                            <option value="153">Nepal</option>
                                                            <option value="154">Netherlands Antilles</option>
                                                            <option value="155">Netherlands The</option>
                                                            <option value="156">New Caledonia</option>
                                                            <option value="157">New Zealand</option>
                                                            <option value="158">Nicaragua</option>
                                                            <option value="159">Niger</option>
                                                            <option value="160">Nigeria</option>
                                                            <option value="161">Niue</option>
                                                            <option value="162">Norfolk Island</option>
                                                            <option value="163">Northern Mariana Islands</option>
                                                            <option value="164">Norway</option>
                                                            <option value="165">Oman</option>
                                                            <option value="166">Pakistan</option>
                                                            <option value="167">Palau</option>
                                                            <option value="168">Palestinian Territory Occupied</option>
                                                            <option value="169">Panama</option>
                                                            <option value="170">Papua new Guinea</option>
                                                            <option value="171">Paraguay</option>
                                                            <option value="172">Peru</option>
                                                            <option value="173">Philippines</option>
                                                            <option value="174">Pitcairn Island</option>
                                                            <option value="175">Poland</option>
                                                            <option value="176">Portugal</option>
                                                            <option value="177">Puerto Rico</option>
                                                            <option value="178">Qatar</option>
                                                            <option value="179">Reunion</option>
                                                            <option value="180">Romania</option>
                                                            <option value="181">Russia</option>
                                                            <option value="182">Rwanda</option>
                                                            <option value="183">Saint Helena</option>
                                                            <option value="184">Saint Kitts And Nevis</option>
                                                            <option value="185">Saint Lucia</option>
                                                            <option value="186">Saint Pierre and Miquelon</option>
                                                            <option value="187">Saint Vincent And The Grenadines
                                                            </option>
                                                            <option value="188">Samoa</option>
                                                            <option value="189">San Marino</option>
                                                            <option value="190">Sao Tome and Principe</option>
                                                            <option value="191">Saudi Arabia</option>
                                                            <option value="192">Senegal</option>
                                                            <option value="193">Serbia</option>
                                                            <option value="194">Seychelles</option>
                                                            <option value="195">Sierra Leone</option>
                                                            <option value="196">Singapore</option>
                                                            <option value="197">Slovakia</option>
                                                            <option value="198">Slovenia</option>
                                                            <option value="199">Smaller Territories of the UK</option>
                                                            <option value="200">Solomon Islands</option>
                                                            <option value="201">Somalia</option>
                                                            <option value="202">South Africa</option>
                                                            <option value="203">South Georgia</option>
                                                            <option value="204">South Sudan</option>
                                                            <option value="205">Spain</option>
                                                            <option value="206">Sri Lanka</option>
                                                            <option value="207">Sudan</option>
                                                            <option value="208">Suriname</option>
                                                            <option value="209">Svalbard And Jan Mayen Islands</option>
                                                            <option value="210">Swaziland</option>
                                                            <option value="211">Sweden</option>
                                                            <option value="212">Switzerland</option>
                                                            <option value="213">Syria</option>
                                                            <option value="214">Taiwan</option>
                                                            <option value="215">Tajikistan</option>
                                                            <option value="216">Tanzania</option>
                                                            <option value="217">Thailand</option>
                                                            <option value="218">Togo</option>
                                                            <option value="219">Tokelau</option>
                                                            <option value="220">Tonga</option>
                                                            <option value="221">Trinidad And Tobago</option>
                                                            <option value="222">Tunisia</option>
                                                            <option value="223">Turkey</option>
                                                            <option value="224">Turkmenistan</option>
                                                            <option value="225">Turks And Caicos Islands</option>
                                                            <option value="226">Tuvalu</option>
                                                            <option value="227">Uganda</option>
                                                            <option value="228">Ukraine</option>
                                                            <option value="229">United Arab Emirates</option>
                                                            <option value="230">United Kingdom</option>
                                                            <option value="231">United States</option>
                                                            <option value="232">United States Minor Outlying Islands
                                                            </option>
                                                            <option value="233">Uruguay</option>
                                                            <option value="234">Uzbekistan</option>
                                                            <option value="235">Vanuatu</option>
                                                            <option value="236">Vatican City State (Holy See)</option>
                                                            <option value="237">Venezuela</option>
                                                            <option value="238">Vietnam</option>
                                                            <option value="239">Virgin Islands (British)</option>
                                                            <option value="240">Virgin Islands (US)</option>
                                                            <option value="241">Wallis And Futuna Islands</option>
                                                            <option value="242">Western Sahara</option>
                                                            <option value="243">Yemen</option>
                                                            <option value="244">Yugoslavia</option>
                                                            <option value="245">Zambia</option>
                                                            <option value="246">Zimbabwe</option>
                                                            <option value="247">Dubai</option>
                                                            <option value="248"></option>
                                                        </select>
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="form_email">Region *</label>
                                                        <select id="region" name="region" class="form-control"
                                                            required="required" data-error="Select Region"
                                                            onchange="getRegion(this.value);getPackage();">
                                                            <option value="">Select Region</option>
                                                        </select>
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="form_email">City *</label>
                                                        <select id="city" name="city" class="form-control"
                                                            required="required" data-error="Select City">
                                                            <option value="">Select City *</option>
                                                        </select>
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="form_email">Locality</label>
                                                        <input type="text" class="form-control"
                                                            placeholder="Enter Locality" name="locality" id="locality">
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="form_email">ZIP Code</label>
                                                        <input id="zipcode" type="text" name="zipcode"
                                                            class="form-control" placeholder="Please enter a Valid Zip "
                                                            data-error="Zip does not match to selected city">
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="form_email">Meta Keywords (optional)</label>
                                                        <input id="keywords" type="text" name="keywords"
                                                            class="form-control"
                                                            placeholder="Please enter few keywords">
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="form_name">Choose Plan *</label>
                                                        <br>
                                                        <div class="pricing-wrapper clearfix packagemob">
                                                            <!-- ======= Pricing Table ============-->
                                                            <div class="pricing-table">
                                                                <h3 class="pricing-title">Free Ad Plan</h3>
                                                                <ul class="table-list">

                                                                    <!--<li><span> -->
                                                                    <!--</span></li>-->
                                                                    <!--<li><//?php echo $pack->no_words;?></li>-->
                                                                    <li>Select Duration <span><input value="5"
                                                                                type="checkbox" id="package5"
                                                                                name="package[]"
                                                                                onchange="selectdays(5);"></span></li>
                                                                    <li>
                                                                        <input type="text" name="day[]" disabled="true"
                                                                            readonly="true" class="form-control"
                                                                            value="700 Days " id="freead">
                                                                    </li>
                                                                    <li>
                                                                        <div class="form-text">
                                                                            <label for="night"
                                                                                class="static-value-price">Price</label>
                                                                            <span class="price-icon"><i
                                                                                    class="fa fa-inr"></i></span>
                                                                            <input style="width:50%" type="text"
                                                                                name="p_price[]" disabled="true"
                                                                                class="package_price" id="price5"
                                                                                value="0" readonly="true">
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                            <div class="pricing-table">
                                                                <h3 class="pricing-title2">Premium Listing</h3>
                                                                <ul class="table-list">
                                                                    <!-- <li><span> -->
                                                                    <!--</span></li>-->
                                                                    <!--<li><//?php echo $pack->no_words;?></li>-->
                                                                    <li>Select Duration <span><input value="4"
                                                                                type="checkbox" id="package4"
                                                                                name="package[]"
                                                                                onchange="selectdays(4);"></span></li>
                                                                    <li>
                                                                        <select disabled="true" name="day[]" id="day4"
                                                                            class="form-control"
                                                                            onchange="getPrice(4,this.value);">
                                                                            <option value="">Select Duration</option>
                                                                            <option value="7">1 Week</option>
                                                                            <option value="14">2 Week</option>
                                                                            <option value="21">3 Week</option>
                                                                            <option value="28">4 Week</option>
                                                                            <option value="35">5 Week</option>
                                                                            <option value="42">6 Week</option>
                                                                            <option value="49">7 Week</option>
                                                                            <option value="56">8 Week</option>
                                                                            <option value="63">9 Week</option>
                                                                            <option value="70">10 Week</option>
                                                                            <option value="77">11 Week</option>
                                                                            <option value="84">12 Week</option>
                                                                            <option value="91">13 Week</option>
                                                                            <option value="98">14 Week</option>
                                                                            <option value="105">15 Week</option>
                                                                        </select>
                                                                    </li>
                                                                    <li>
                                                                        <div class="form-text">
                                                                            <label for="night"
                                                                                class="static-value-price">Price</label>
                                                                            <span class="price-icon"><i
                                                                                    class="fa fa-inr"></i></span>
                                                                            <input style="width:50%" type="text"
                                                                                name="p_price[]" disabled="true"
                                                                                class="package_price" id="price4"
                                                                                value="0" readonly="true">
                                                                        </div>
                                                                    </li>
                                                                    <!--<li>Price <span><input type="text" name="p_price[]" disabled="true"  Class="form-control" id="price4" value="390" readonly="true"></span></li>-->
                                                                </ul>
                                                            </div>
                                                            <div class="pricing-table">
                                                                <h3 class="pricing-title3">Sidebar Gallery</h3>
                                                                <ul class="table-list">
                                                                    <!-- <li><span> -->
                                                                    <!--</span></li>-->
                                                                    <!--<li><//?php echo $pack->no_words;?></li>-->
                                                                    <li>Select Duration <span><input value="3"
                                                                                type="checkbox" id="package3"
                                                                                name="package[]"
                                                                                onchange="selectdays(3);"></span></li>
                                                                    <li>
                                                                        <select disabled="true" name="day[]" id="day3"
                                                                            class="form-control"
                                                                            onchange="getPrice(3,this.value);">
                                                                            <option value="">Select Duration</option>
                                                                            <option value="7">1 Week</option>
                                                                            <option value="14">2 Week</option>
                                                                            <option value="21">3 Week</option>
                                                                            <option value="28">4 Week</option>
                                                                            <option value="35">5 Week</option>
                                                                            <option value="42">6 Week</option>
                                                                            <option value="49">7 Week</option>
                                                                            <option value="56">8 Week</option>
                                                                            <option value="63">9 Week</option>
                                                                            <option value="70">10 Week</option>
                                                                            <option value="77">11 Week</option>
                                                                            <option value="84">12 Week</option>
                                                                            <option value="91">13 Week</option>
                                                                            <option value="98">14 Week</option>
                                                                            <option value="105">15 Week</option>
                                                                        </select>
                                                                    </li>
                                                                    <li>
                                                                        <div class="form-text">
                                                                            <label for="night"
                                                                                class="static-value-price">Price</label>
                                                                            <span class="price-icon"><i
                                                                                    class="fa fa-inr"></i></span>
                                                                            <input style="width:50%" type="text"
                                                                                name="p_price[]" disabled="true"
                                                                                class="package_price" id="price3"
                                                                                value="0" readonly="true">
                                                                        </div>
                                                                    </li>
                                                                    <!--<li>Price <span><input type="text" name="p_price[]" disabled="true"  Class="form-control" id="price3" value="390" readonly="true"></span></li>-->
                                                                </ul>
                                                            </div>
                                                            <div class="pricing-table">
                                                                <h3 class="pricing-title4">Slider Ads</h3>
                                                                <ul class="table-list">
                                                                    <!-- <li><span>-->
                                                                    <!--</span></li>-->
                                                                    <!--<li><//?php echo $pack->no_words;?></li>-->
                                                                    <li>Select Duration <span><input value="1"
                                                                                type="checkbox" id="package1"
                                                                                name="package[]"
                                                                                onchange="selectdays(1);"></span></li>
                                                                    <li>
                                                                        <select disabled="true" name="day[]" id="day1"
                                                                            class="form-control"
                                                                            onchange="getPrice(1,this.value);">
                                                                            <option value="">Select Duration</option>
                                                                            <option value="7">1 Week</option>
                                                                            <option value="14">2 Week</option>
                                                                            <option value="21">3 Week</option>
                                                                            <option value="28">4 Week</option>
                                                                            <option value="35">5 Week</option>
                                                                            <option value="42">6 Week</option>
                                                                            <option value="49">7 Week</option>
                                                                            <option value="56">8 Week</option>
                                                                            <option value="63">9 Week</option>
                                                                            <option value="70">10 Week</option>
                                                                            <option value="77">11 Week</option>
                                                                            <option value="84">12 Week</option>
                                                                            <option value="91">13 Week</option>
                                                                            <option value="98">14 Week</option>
                                                                            <option value="105">15 Week</option>
                                                                        </select>
                                                                    </li>
                                                                    <li>
                                                                        <div class="form-text">
                                                                            <label for="night"
                                                                                class="static-value-price">Price</label>
                                                                            <span class="price-icon"><i
                                                                                    class="fa fa-inr"></i></span>
                                                                            <input style="width:50%" type="text"
                                                                                name="p_price[]" disabled="true"
                                                                                class="package_price" id="price1"
                                                                                value="0" readonly="true">
                                                                        </div>
                                                                    </li>
                                                                    <!--<li>Price <span><input type="text" name="p_price[]" disabled="true"  Class="form-control" id="price1" value="390" readonly="true"></span></li>-->
                                                                </ul>
                                                            </div>
                                                            <div class="pricing-table">
                                                                <h3 class="pricing-title5">Fixed Position</h3>
                                                                <ul class="table-list">
                                                                    <!--<li><span> -->
                                                                    <!--</span></li>-->
                                                                    <!--<li><//?php echo $pack->no_words;?></li>-->
                                                                    <li>Select Duration <span><input value="6"
                                                                                type="checkbox" id="package6"
                                                                                name="package[]"
                                                                                onchange="selectdays(6);"></span></li>
                                                                    <li>
                                                                        <select disabled="true" name="day[]" id="day6"
                                                                            class="form-control"
                                                                            onchange="getPrice(6,this.value);">
                                                                            <option value="">Select Duration</option>




                                                                            <option value="7">1 Week</option>
                                                                            <option value="14">2 Week</option>
                                                                            <option value="21">3 Week</option>
                                                                            <option value="28">4 Week</option>
                                                                            <option value="35">5 Week</option>
                                                                            <option value="42">6 Week</option>
                                                                            <option value="49">7 Week</option>
                                                                            <option value="56">8 Week</option>
                                                                            <option value="63">9 Week</option>
                                                                            <option value="70">10 Week</option>
                                                                            <option value="77">11 Week</option>
                                                                            <option value="84">12 Week</option>
                                                                            <option value="91">13 Week</option>
                                                                            <option value="98">14 Week</option>
                                                                            <option value="105">15 Week</option>
                                                                        </select>
                                                                    </li>
                                                                    <li>
                                                                        <div class="form-text">
                                                                            <label for="night"
                                                                                class="static-value-price">Price</label>
                                                                            <span class="price-icon"><i
                                                                                    class="fa fa-inr"></i></span>
                                                                            <input style="width:50%" type="text"
                                                                                name="p_price[]" disabled="true"
                                                                                class="package_price" id="price6"
                                                                                value="0" readonly="true">
                                                                        </div>
                                                                    </li>
                                                                    <!--<li>Price <span><input type="text" name="p_price[]" disabled="true"  Class="form-control" id="price6" value="290" readonly="true"></span></li>-->
                                                                </ul>
                                                            </div>
                                                            <!-- ======= Pricing Table ============-->
                                                        </div>
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="form_email">Meta Description (optional)</label>
                                                        <textarea rows="10" id="metadesc" name="metadesc"
                                                            class="form-control"
                                                            placeholder="Please enter the description for entered keywords "></textarea>
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="form_email">Upload Images(
                                                            <font style="color:#ec0c0c"> Maximum 10 images can be
                                                                uploaded </font>) *</label>
                                                        <div id="maindiv">
                                                            <div id="formdiv">
                                                                <div class="">

                                                                    <div id="imageDiv"> </div>
                                                                    <div id="filediv" style="">
                                                                        <input name="file[]" type="file" id="file"
                                                                            multiple="">
                                                                        <input type="hidden" value="0"
                                                                            id="post_img_count">
                                                                    </div>
                                                                    <div id="bottom">
                                                                        <input type="button" id="add_more"
                                                                            class="upload" value="Add More Files">
                                                                    </div>

                                                                </div>
                                                            </div>
                                                            <div class="help-block with-errors"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <br>
                                                <br>
                                                <div class="row1">
                                                    <div class="col-md-12"
                                                        style="padding-left: 0px; float: left; position: relative; margin-top: 20px;">
                                                        <div class="col-md-12" style="padding-left: 0px;">
                                                            <div class="col-md-4">
                                                                <div id="captcha"></div>
                                                                <input type="text" class="form-control"
                                                                    placeholder="Enter the text here."
                                                                    id="cpatchaTextBox" required="">
                                                            </div>
                                                        </div>
                                                        <input type="submit" class="btn btn-success btn-send"
                                                            style="margin: 15px 10px; position: relative;"
                                                            value="Create Add">
                                                    </div>
                                                </div>
                                                <p class="text-muted"><strong>*</strong> These fields are required.</p>
                                            </div>

                                        </div>
                                    </form>
                                    <!-- /.8 -->
                                    <div class="col-md-3">
                                        <!--<img src="http://addgalaxy.com/assests\home\images\sidebar.jpg" width="800px" height "2000px"> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <script>
                            $(document).ready(function () {
                                $('#total_ads_count').text('9');
                                $('.total_ads_countnew').text('9');
                            });
                        </script>
                    </div>
                    <div class="col-md-6 col-sm-8" id="textImage" style="display:none">
                        <div class="container">
                            <div class="row">
                                <div class="">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th><span id="ad_with_img_count">0 </span><span> Results for your
                                                        search</span></th>
                                            </tr>
                                        </thead>
                                        <tbody id="myTable">

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <script>
                        $("#ad_with_img_count").text('0 ')
                    </script>


                    <div class="col-xs-12" id="text2Image" style="display:none">
                        <div class="container">
                            <div class="row">
                                <div class="">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th><span id="ad_without_img_count">0 </span><span> Results for your
                                                        search</span></th>
                                            </tr>
                                        </thead>
                                        <tbody id="myTable">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <script>
                        $("#ad_without_img_count").text('0 ')
                    </script>
                </div>
            </div>

            <!-- Right side Gallery-->
            <div class="col-md-3 col-sm-3 mb-xs-30" id="right-side-gallery" style="padding-left: 0px;">
                <div class="sidebar-block right-side-color graybox1">

                </div>
            </div>
        </div>
        <!-- Right side gallery end -->


    </div>

</section>
<?php echo view('footer',$extras);?>