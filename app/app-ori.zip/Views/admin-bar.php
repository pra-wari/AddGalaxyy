<div class="row">
                    <div class="col-md-3">
                        <select name="action" class="form-control">
                            <option value="10">Bulk Action</option>
                            <option value="delete">Delete</option>
                        </select>
                    </div>
                    <div class="col-md-3 entryClass">
                        <span class="searchspan">Show: </span>
                        <select name="showentry" class="form-control entries">
                            <option value="10">10</option>
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                        </select>
                        <span class="searchspan"> entries</span>
                    </div>
                    <div class="col-md-3 entryClass">
                        <span class="searchspan">Short: </span>
                        <select name="sortdate" class="form-control">
                            <option value="">Date</option>
                            <option value="25">25-OCT-2020</option>
                            <option value="50">26-OCT-2020</option>
                            <option value="100">27-OCT-2020</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group pull-right" style="display: inline-flex;">
                            <span class="searchspan">Search: </span><input type="text" class="search form-control"
                                placeholder="What you looking for?">
                        </div>
                    </div>
                </div>
<script>
$(document).ready(function(){
    $("#checkAll").change(function () {
        $("input:checkbox").prop('checked', $(this).prop("checked"));
    });
});
</script>