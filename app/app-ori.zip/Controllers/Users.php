<?php namespace App\Controllers;
use App\Models\Categories;
use App\Models\Listing;
use App\Models\UserModel;
use App\Models\Plans;
use App\Models\PlansMeta;
use App\Models\Attributes;
use App\Models\Countries;
use App\Models\Invoice;
use App\Models\Transactions;
use App\Models\MainAttributes;
use App\Models\ListingImages;
use App\Models\UsersPlanRelationship;
use App\Models\RelListingAttribute;
use CodeIgniter\Config\Config;
use CodeIgniter\Controller;
use CodeIgniter\I18n\Time;


class Users extends Controller
{
	public function login()
	{
		$data = [];
		$data1= array();
		helper(['form']);


		if ($this->request->getMethod() == 'post') {
			//let's do the validation here
			$rules = [
				'email' => 'required|min_length[6]|max_length[50]|valid_email',
				'password' => 'required|min_length[8]|max_length[255]',
			];

			$errors = [
				'password' => [
					'validateUser' => 'Email or Password don\'t match'
				]
			];

			if (! $this->validate($rules, $errors)) {
				$data['validation'] = $this->validator;
			}else{
				$model = new UserModel();
				$user = $model->where('email', $this->request->getVar('email'))->first();
				if(isset($user['id'])){
					$this->setUserSession($user);
					if($user['usertype']=='admin'){
						return redirect()->to('/admin');
					}else{
						return redirect()->to('/dashboard');
					}
				}else{
					$session->setFlashdata('fail', 'This Account Does not exists!');
					return redirect()->to('/login');
				}
			}
		}

		$cat1 = new Categories();
	    $data1['categories'] = $cat1->findAll();
		echo view('login',$data1);
		
	}

	private function setUserSession($user){
		$data = [
			'id' => $user['id'],
			'firstname' => $user['firstname'],
			'lastname' => $user['lastname'],
			'email' => $user['email'],
			'username' => $user['username'],
			'usertype' => $user['usertype'],
			'isLoggedIn' => true,
		];

		session()->set($data);
		return true;
	}

	public function register(){
		$data = [];
		$cat1 = new Categories();
	    $data['categories'] = $cat1->findAll();
		helper(['form']);
		if ($this->request->getMethod() == 'post') {
			//let's do the validation here
			$rules = [
				'sfirstname' => 'required|min_length[3]|max_length[20]',
				'slastname' => 'required|min_length[3]|max_length[20]',
				'email' => 'required|min_length[6]|max_length[50]',
				'password' => 'required|min_length[8]|max_length[255]',
				'password_confirm' => 'matches[password]',
				'mobile'=>  'min_length[3]',
			];

			if (! $this->validate($rules)) {
				$data['validationSignup'] = $this->validator;
			}else{
				$model = new UserModel();
				$newData = [
					'firstname' => $this->request->getVar('sfirstname'),
					'lastname' => $this->request->getVar('slastname'),
					'email' => $this->request->getVar('email'),
					'password' => $this->request->getVar('password'),
					'mobile' => $this->request->getVar('mobile'),
				];
				$model->save($newData);
				$session = session();
				$model = new UserModel();
				$user = $model->where('email', $this->request->getVar('email'))->first();
				$this->setUserSession($user);
				$session->setFlashdata('success', 'Successful Registration');
				return redirect()->to('/');
			}
		}


		
		echo view('login',$data);
		
	}

	public function profile(){
		
		$data = [];
		$cat1 = new Categories();
	    $data['categories'] = $cat1->findAll();
		helper(['form']);
		$model = new UserModel();

		if ($this->request->getMethod() == 'post') {
			//let's do the validation here
			$rules = [
				'firstname' => 'required|min_length[3]|max_length[20]',
				'lastname' => 'required|min_length[3]|max_length[20]',
				];

			if($this->request->getPost('password') != ''){
				$rules['password'] = 'required|min_length[8]|max_length[255]';
				$rules['password_confirm'] = 'matches[password]';
			}


			if (! $this->validate($rules)) {
				$data['validation'] = $this->validator;
			}else{

				$newData = [
					'id' => session()->get('id'),
					'firstname' => $this->request->getPost('firstname'),
					'lastname' => $this->request->getPost('lastname'),
					];
					if($this->request->getPost('password') != ''){
						$newData['password'] = $this->request->getPost('password');
					}
				$model->save($newData);

				session()->setFlashdata('success', 'Successfuly Updated');
				return redirect()->to('/profile');

			}
		}

		$data['user'] = $model->where('id', session()->get('id'))->first();
		
		echo view('profile');
		
	}
	public function messages($userid){
		echo 'Page Coming Soon. Thanks for visit';
	}

	public function invoices($userid){
		$session = session();
		$db = \Config\Database::connect();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$data = array();
		$request = \Config\Services::request();
		$session = session();
		$userid = $session->get('id');
		$invoice = new Invoice();
		$user = new UserModel();
		$plans = new Plans();
		$cat1 = new Categories();
	    $data['categories'] = $cat1->findAll();
		$invoice->where('deleted',0);
		$invoice->where('user_id',$userid);
		$pager = \Config\Services::pager();
		$result = $invoice->paginate(6);
		foreach ($result as $key => $value) {
			$res = $db->query("Select email from users where id='".$value['user_id']."'");
			$userresult = $res->getResult('array');
			$result[$key]['email'] = $userresult[0]['email'];
			$res1 = $db->query("Select plan_id,plan_duration from plans_meta where id='".$value['plan_id']."'");
			$planresult = $res1->getResult('array');
			$result[$key]['plan_duration'] = $planresult[0]['plan_duration'];
			$res2 = $db->query("Select plan_name from plans where id='".$planresult[0]['plan_id']."'");
			$planresult1 = $res2->getResult('array');
			$result[$key]['plan_name'] = $planresult1[0]['plan_name'];
		}
		$data['invoice'] = $result;
		$data['currentpage'] = $request->uri->getSegment(2);
		$data['pager'] = $invoice->pager;
		return view('user-invoice',$data);
	}

	/*public function logout(){
		session()->destroy();
		return redirect()->to('/');
	}*/
	public function submitad(){
		$listing = new Listing();
		$UserPlanRelationship = new UsersPlanRelationship();
		$PlansMeta = new PlansMeta();
		$Transactions = new Transactions();
		$Invoice = new Invoice();
		$ListingImages = new ListingImages();
		$RelListingAttribute = new RelListingAttribute();
		$request = $this->request->getVar();
		$session = session();
		$userid = $session->get('id');
		$listingData = [
			'title' => $request['title'],
			'price' => $request['price'],
			'location' => $request['region'],
			'category_id' => $request['subcategory']?$request['subcategory']:$request['category'],
			'description' => $request['desc'],
			'user_id' => $userid,
			'featured' => $request['plantype']=='featured'?1:0,
			'premium' => $request['plantype']=='premium'?1:0,
			'sgallery' => $request['plantype']=='sgallery'?1:0,
			'valid' => 1,
			'modified_date' => Time::now(),
		];
		$listing->save($listingData);
		$insertedId = $listing->insertID();
		if($insertedId){
			if($imagefile = $this->request->getFiles())
			{	
				$i=0;
				foreach($imagefile['file'] as $img)
				{
					$i++;
					if ($img->isValid() && ! $img->hasMoved())
					{
						if($i==1){
							$newName = $img->getRandomName();
							$imageData = [
								'id' => $insertedId,
								'images' => 'public/uploads/'.$newName
							];
							$listing->save($imageData);
							$img->move(APPPATH.'../public/uploads', $newName);
						}else{
							$newName = $img->getRandomName();
							$imageData = [
								'listing_id' => $insertedId,
								'image_path' => 'public/uploads/'.$newName,
								'created_date' => Time::now(),
								'created_date' => Time::now(),
							];
							$ListingImages->save($imageData);
							$img->move(APPPATH.'../public/uploads', $newName);
						}
					}
				}
			}
			foreach ($request['name'] as $ks1 => $vs1) {
				$attrRelation=[
					'listing_id' => $insertedId,
					'attribute_id' => $vs1,
				];
				$RelListingAttribute->save($attrRelation);
			}
			$plans = $PlansMeta->where('id',$request['selectedDuration'])->first();
			$myTime = new Time('+'.$plans['planindays'].' days');
			$uniqueId= time().'-'.mt_rand();
			$currentTime = Time::now();
			$currentTime = str_replace(" ","",$currentTime);
			$currentTime = str_replace("-","",$currentTime);
			$currentTime = str_replace(":","",$currentTime);
			$plansData = [
				'user_id' => $userid,
				'plan_id' => $request['selectedDuration'],
				'plan_start_date' => Time::now(),
				'plan_end_date' => $myTime,
				'valid' => 1,
				'created_at' => Time::now(),
				'modified_date' => Time::now(),
			];
			$UserPlanRelationship->save($plansData);
			$transactionData = [
				'user_id' => $userid,
				'plan_id' => $request['selectedDuration'],
				'transaction_id' => $currentTime,
				'transaction_response' => '',
				'transaction_status' => 'success',
				'transaction_date' => Time::now(),
			];
			$Transactions->save($transactionData);
			$invoiceData = [
				'user_id' => $userid,
				'plan_id' => $request['selectedDuration'],
				'price' => $request['price'],
				'valid' => 1,
				'created_at' => Time::now(),
				'modified_at' => Time::now(),
			];
			$Invoice->save($invoiceData);
			$session->setFlashdata('success', 'Ad Submitted Successfully');
			return redirect()->to('/');
		}
	}

	public function postad(){
		$db = \Config\Database::connect();
		$data = array();	 
	  	$cat = new Categories();
	  	$countries = new Countries();
	  	$cat->where('deleted',0);
	  	//$countries->where('deleted',0);
	  	$data = $cat->findAll();
	  	$catArray = array();
	  	foreach ($data as $key => $value){
			if($value['parent_id']==0){
				$catArray[] = $value; 
			}
	}
   
   foreach ($catArray as $k => $v) {
      foreach ($data as $key => $value1){
       if($v['id']==$value1['parent_id']){
        $catArray[$k]['subCategory'][] = $value1; 
       }
    }
   }

$queryplan = $db->query("SELECT * FROM plans WHERE valid=1 AND deleted=0");
$planArray = array();
foreach ($queryplan->getResult() as $rowplan)
{
    $temp['id'] = $rowplan->id;
    $temp['plan_name'] = $rowplan->plan_name;
    $temp['type'] = $rowplan->type;
    

    $query_planmeta = $db->query("SELECT * FROM plans_meta WHERE valid=1 AND deleted=0 AND plan_id=".$temp['id']);
    $result_subatt = array();
    $i=0;
    $temp3 = array();
    foreach ($query_planmeta->getResult() as $row_subatt)
    {
            $temp2['id'] = $row_subatt->id;
            $temp2['plan_duration'] = $row_subatt->plan_duration;
            $temp2['plan_price'] = $row_subatt->plan_price;
            array_push($temp3, $temp2);
          $i++;
    }
    $temp['meta']=$temp3;
    // echo "<pre>";
    // print_r($temp);
    // echo "</pre>";
        array_push($planArray, $temp);
}

   $data['plans'] = $planArray;
   $data['categories'] = $catArray;
   $data['countries'] = $countries->findAll();;
		echo view('postad',$data);
	}

	public function editlisting($listId){
		$data = array();
		$listing = new Listing();
		$listing->where('deleted',0);
		$result = $listing->where('id',$listId)->findAll(); 
		$cat1 = new Categories();
	    $data['categories'] = $cat1->findAll();
		$data['listing'] = $result;
		return view('edit-listing',$data);
	}

	public function deletelisting($listId){
		$listing = new Listing();
		$listingData = [
			'id'=>$listId,
			'deleted' => 1
		];
		$listing->save($listingData);
		$session = session();
        $session->setFlashdata('success', 'Successfully deleted the listing');
		return redirect()->to(base_url('/dashboard'));
	}
	public function disablelisting($listId){
		$listing = new Listing();
		$listingData = [
			'id'=>$listId,
			'valid' => 0
		];
		$listing->save($listingData);
		$session = session();
        $session->setFlashdata('success', 'Successfully deleted the listing');
		return redirect()->to(base_url('/dashboard'));
	}
	public function enablelisting($listId){
		$listing = new Listing();
		$listingData = [
			'id'=>$listId,
			'valid' => 1
		];
		$listing->save($listingData);
		$session = session();
        $session->setFlashdata('success', 'Successfully deleted the listing');
		return redirect()->to(base_url('/dashboard'));
	}

	public function updatepassword($listId){
		$request = \Config\Services::request();
		$data = array();
		$model = new UserModel();
		$user = $model->where('id', $listId)->first();
		$data['user'] = $user;
		$cat1 = new Categories();
		$data['categories'] = $cat1->findAll();
		$data['module'] = $request->uri->getSegment(1);
		$data['currentpage'] = $request->uri->getSegment(2);
		return view('update-password',$data);
	}

	public function changepassword(){
		$data = array();
		$request = \Config\Services::request();
		$session = session();
		//print_r($this->request->getVar());
		$id = $this->request->getVar('uid');
		$password = $this->request->getVar('password');
		$confirm_password = $this->request->getVar('confirm_password');
		$UserModel = new UserModel();
		if($password == $confirm_password){
			$userData = [
				'id'=>$id,
				'password' => $password
			];
			//print_r($userData);
			$UserModel->save($userData);
			$user = $UserModel->where('id', $id)->first();
			$data['user'] = $user;
			$cat1 = new Categories();
			$data['categories'] = $cat1->findAll();
			$data['module'] = $request->uri->getSegment(1);
			$data['currentpage'] = $request->uri->getSegment(2);
			$session->setFlashdata('success', 'Password successfully Changed');
			return view('update-password',$data);
		}

	}
	public function editprofile($userid){
		$request = \Config\Services::request();
		$data = array();
		$model = new UserModel();
		$user = $model->where('id', $userid)->first();
		$data['user'] = $user;
		$cat1 = new Categories();
	    $data['categories'] = $cat1->findAll();
		$data['module'] = $request->uri->getSegment(1);
		$data['currentpage'] = $request->uri->getSegment(2);
		return view('edit-profile',$data);
	}

	public function updateProfile(){
		$request = \Config\Services::request();
		$uid = $this->request->getVar('uid');
		$sfirstname = $this->request->getVar('sfirstname');
		$slastname = $this->request->getVar('slastname');
		$mobile = $this->request->getVar('mobile');
		$model = new UserModel();
		$userData = [
			'id'=>$uid,
			'firstname' => $sfirstname,
			'lastname' => $slastname,
			'mobile' => $mobile,
		];
		$model->save($userData);
		$session = session();
		$session->setFlashdata('success', 'Profile successfully Update');
		$user = $model->where('id', $uid)->first();
		$data['user'] = $user;
		$cat1 = new Categories();
	    $data['categories'] = $cat1->findAll();
		$data['module'] = $request->uri->getSegment(1);
		$data['currentpage'] = $request->uri->getSegment(2);
		//return view('edit-profile',$data);
		return redirect()->to('/users/editprofile/'.$uid);
	}

	public function logout(){
		$session = session();
		session()->destroy();
		$session = session();
		$session->setFlashdata('success', 'Successfully Logout');
		return redirect()->to('/');
	}

	public function fetchpostaddata(){
		$data = array(); 
		$request = \Config\Services::request();
		$catid = $this->request->getVar('id');
		$categories = new Categories();
		$attributes = new MainAttributes();
		$attributesmeta = new Attributes();
		$attributes->where('deleted',0);
		$attributes->where('parent_category_id',$catid);
		$categories->where('parent_id',$catid);
		$categories->where('deleted',0);
		$attributesarray = $attributes->findAll();
		foreach ($attributesarray as $key => $value) {
			$attributesmeta->where('deleted',0);
			$attributesmeta->where('parent_attribute_id',$value['id']);
			$attributesarray[$key]['option'] = $attributesmeta->findAll();
		}
		$data['subCategory'] = $categories->findAll();
		$data['attributes'] = $attributesarray;
		echo json_encode($data);
	}
	//--------------------------------------------------------------------

}