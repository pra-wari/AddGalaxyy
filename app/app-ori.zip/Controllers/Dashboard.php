<?php namespace App\Controllers;
use App\Models\Categories;
use App\Models\Listing;
use App\Models\UserModel;
use CodeIgniter\Config\Config;
use CodeIgniter\Controller;

class Dashboard extends BaseController
{
	public function index()
	{
		$data = [];
        $session = session();
        $isloggedin = session()->get('isLoggedIn');
        $db = \Config\Database::connect();
        if($isloggedin){
            $data = array();
            $request = \Config\Services::request();
            $userid = $session->get('id');
            $listing = new Listing();
            $listing->where('deleted',0);
            $result = $listing->where('user_id',$userid)->findAll();
            $pager = \Config\Services::pager();
            $cat1 = new Categories();
            foreach ($result as $key1 => $value1) {
                $res1 = $db->query("SELECT plans.`plan_name` FROM users_plan_relation 
                INNER JOIN plans_meta ON users_plan_relation.`plan_id`= plans_meta.id
                INNER JOIN plans ON plans_meta.`plan_id` = plans.id
                WHERE users_plan_relation.listing_id='".$value1['id']."'");
                $result[$key1]['plans'] = $res1->getResult('array');
                $res = $db->query("Select name from categories where id='".$value1['category_id']."'");
                $result[$key1]['categoryName'] = $res->getResult('array')[0]['name'];
                $res = $db->query("Select name from region where id='".$value1['location']."'");
                $result[$key1]['region'] = $res->getResult('array')[0]['name'];
            }
	        $data['categories'] = $cat1->findAll();
            $data['listing'] = $result;
            $data['currentpage'] = $request->uri->getSegment(2);
            echo view('dashboard',$data);
        }else{
            echo 'entered';
            return redirect()->to('login');
        }
        
	}

	//--------------------------------------------------------------------

}