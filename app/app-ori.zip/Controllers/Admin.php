<?php namespace App\Controllers;
use App\Models\Categories;
use App\Models\Listing;
use App\Models\UserModel;
use App\Models\Plans;
use App\Models\PlansMeta;
use App\Models\Attributes;
use App\Models\Invoice;
use App\Models\MainAttributes;
use CodeIgniter\Config\Config;
use CodeIgniter\Controller;
use CodeIgniter\I18n\Time;

class Admin extends Controller
{
	public function checkLogin(){
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
	}
	public function index()
	{	
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$data = array();
		$cat1 = new Categories();
	    $data['categories'] = $cat1->findAll();
		$request = \Config\Services::request();
		$listing = new Listing();
		$listing->where('deleted',0);
		$listing->where('user_id',$userid);
		$pager = \Config\Services::pager();
		$data['listing'] = $listing->paginate(6);
		$data['currentpage'] = $request->uri->getSegment(2);
		$data['pager'] = $listing->pager;
		return redirect()->to(base_url('/admin/allads'));
		//return view('admin-dashboard',$data);
	}

	public function editlisting($listId){
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$data = array();
		$cat1 = new Categories();
		$request = \Config\Services::request();
	    $data['categories'] = $cat1->findAll();
		$listing = new Listing();
		$listing->where('deleted',0);
		$result = $listing->where('id',$listId)->findAll(); 
		$data['currentpage'] = $request->uri->getSegment(2);
		$data['listing'] = $result;
		return view('edit-listing',$data);
	}

	public function deletelisting($listId){
		$request = \Config\Services::request();
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$listing = new Listing();
		$listingData = [
			'id'=>$listId,
			'deleted' => 1
		];
		$listing->save($listingData);
		$session = session();
        $session->setFlashdata('success', 'Successfully deleted the listing');
		return redirect()->to(base_url('/admin'));
	}

	public function updatepassword($listId){
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$request = \Config\Services::request();
		$data = array();
		$cat1 = new Categories();
	    $data['categories'] = $cat1->findAll();
		$model = new UserModel();
		$user = $model->where('id', $listId)->first();
		$data['user'] = $user;
		$data['module'] = $request->uri->getSegment(1);
		$data['currentpage'] = $request->uri->getSegment(2);
		return view('update-password',$data);
	}

	public function changepassword(){
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$data = array();
		$cat1 = new Categories();
	    $data['categories'] = $cat1->findAll();
		$request = \Config\Services::request();
		$session = session();
		$id = $this->request->getVar('uid');
		$password = $this->request->getVar('password');
		$confirm_password = $this->request->getVar('confirm_password');
		$UserModel = new UserModel();
		if($password == $confirm_password){
			$userData = [
				'id'=>$id,
				'password' => $password
			];
			$UserModel->save($userData);
			$user = $UserModel->where('id', $id)->first();
			$data['user'] = $user;
			$data['module'] = $request->uri->getSegment(1);
			$data['currentpage'] = $request->uri->getSegment(2);
			$session->setFlashdata('success', 'Password successfully Changed');
			return view('update-password',$data);
		}

	}
	public function editprofile($userid){
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$request = \Config\Services::request();
		$data = array();
		$model = new UserModel();
		$cat1 = new Categories();
	    $data['categories'] = $cat1->findAll();
		$user = $model->where('id', $userid)->first();
		$data['user'] = $user;
		$data['module'] = $request->uri->getSegment(1);
		$data['currentpage'] = $request->uri->getSegment(2);
		return view('edit-profile',$data);
	}

	public function updateProfile(){
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$request = \Config\Services::request();
		$uid = $this->request->getVar('uid');
		$sfirstname = $this->request->getVar('sfirstname');
		$slastname = $this->request->getVar('slastname');
		$mobile = $this->request->getVar('mobile');
		$data=array();
		$model = new UserModel();
		$cat1 = new Categories();
	    $data['categories'] = $cat1->findAll();
		$userData = [
			'id'=>$uid,
			'firstname' => $sfirstname,
			'lastname' => $slastname,
			'mobile' => $mobile,
		];
		$model->save($userData);
		$session = session();
		$session->setFlashdata('success', 'Profile successfully Update');
		$user = $model->where('id', $uid)->first();
		$data['user'] = $user;
		$data['module'] = $request->uri->getSegment(1);
		$data['currentpage'] = $request->uri->getSegment(2);
		return view('edit-profile',$data);
	}

	public function logout(){
		$session = session();
		$session->destroy();
		$session->setFlashdata('success', 'Successfully Logout');
		return redirect()->to('/');
	}

	public function allads(){
		$session = session();
		$db = \Config\Database::connect();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$data = array();
		$cat1 = new Categories();
	    $data['categories'] = $cat1->findAll();
		$request = \Config\Services::request();
		$session = session();
		$userid = $session->get('id');
		$listing = new Listing();
		$listing->where('deleted',0);
		$pager = \Config\Services::pager();
		$result = $listing->paginate(10);
		foreach ($result as $key1 => $value1) {
			$res = $db->query("Select email from users where id='".$value1['user_id']."'");
			$result[$key1]['userEmail'] = $res->getResult('array')[0]['email'];
			$res1 = $db->query("SELECT plans.`plan_name` FROM users_plan_relation 
			INNER JOIN plans_meta ON users_plan_relation.`plan_id`= plans_meta.id
			INNER JOIN plans ON plans_meta.`plan_id` = plans.id
			WHERE users_plan_relation.listing_id='".$value1['id']."'");
			$result[$key1]['plans'] = $res1->getResult('array');
			$res = $db->query("Select name from categories where id='".$value1['category_id']."'");
			$result[$key1]['categoryName'] = $res->getResult('array')[0]['name'];
			$res = $db->query("Select name from region where id='".$value1['location']."'");
			$result[$key1]['region'] = $res->getResult('array')[0]['name'];
		}
		$data['listing'] = $result;
		$data['currentpage'] = $request->uri->getSegment(2);
		$data['pager'] = $listing->pager;
		return view('admin-dashboard',$data);
	}
	/*------- Category Section Starts ----------*/
	public function addcategory(){
		$request = \Config\Services::request();
		$data = array();
		$session = session();
		$categories = new Categories();
		$categories->where('deleted',0);
		$categories->where('parent_id',0);
		$pager = \Config\Services::pager();
		$data['categories'] = $categories->findAll();
		$data['currentpage'] = $request->uri->getSegment(2);
		return view('add-categories',$data);
	}
	public function addnewcategory(){
		$request = \Config\Services::request();
		$session = session();
		$categories = new Categories();
		$currentPage = $session->get('currentPage');
		
		$name = $this->request->getVar('name');
		$slug = $this->request->getVar('slug');
		$category = $this->request->getVar('category');
		$desc = $this->request->getVar('desc');
		if($imagefile = $request->getFiles())
		{
			foreach($imagefile['file'] as $img)
			{
				if ($img->isValid() && ! $img->hasMoved())
				{
					$newName = $img->getRandomName();
					$categoriesData = [
						'name' => $name,
						'slug' => $slug,
						'parent_id' => $category,
						'desc' => $desc,
						'icon_path' => 'public/uploads/'.$newName
					];
					$categories->save($categoriesData);
					$img->move(APPPATH.'../public/uploads', $newName);
					$session->setFlashdata('success', 'Category updated Successfully');
					return redirect()->to(base_url($currentPage));
				}else{
					$categoriesData = [
						'name' => $name,
						'slug' => $slug,
						'parent_id' => $category,
						'desc' => $desc
					];
					$categories->save($categoriesData);
					$session->setFlashdata('error', 'Something Went Wrong. Please try again');
					return redirect()->to(base_url($currentPage));
				}
			}
		}
	}

	public function editcategories(){
		$request = \Config\Services::request();
		$session = session();
		$currentPage = $session->get('currentPage');
		$categories = new Categories();
		$cid = $this->request->getVar('cid');
		$name = $this->request->getVar('name');
		$slug = $this->request->getVar('slug');
		$category = $this->request->getVar('category');
		$desc = $this->request->getVar('desc');
		if($cid==$category){
			$category = 0;
		}
		if($imagefile = $request->getFiles())
		{
			foreach($imagefile['file'] as $img)
			{
				if ($img->isValid() && ! $img->hasMoved())
				{
					$newName = $img->getRandomName();
					$categoriesData = [
						'id'=>$cid,
						'name' => $name,
						'slug' => $slug,
						'parent_id' => $category,
						'desc' => $desc,
						'icon_path' => 'public/uploads/'.$newName
					];
					$categories->save($categoriesData);
					$img->move(APPPATH.'../public/uploads', $newName);
					$session->setFlashdata('success', 'Category updated Successfully');
					return redirect()->to(base_url($currentPage));
				}else{
					$categoriesData = [
						'id'=>$cid,
						'name' => $name,
						'slug' => $slug,
						'parent_id' => $category,
						'desc' => $desc
					];
					$categories->save($categoriesData);
					$session->setFlashdata('error', 'Something Went Wrong. Please try again');
					return redirect()->to(base_url($currentPage));
				}
			}
		}
	}

	public function parentCategories(){
		$request = \Config\Services::request();
		$session = session();
		$session->set(['currentPage' => $request->uri]);
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$data = array();
		
		$session = session();
		$userid = $session->get('id');
		$categories = new Categories();
	    $data['categories'] = $categories->findAll();
		$categories->where('deleted',0);
		$categories->where('parent_id',0);
		$pager = \Config\Services::pager();
		$data['categories'] = $categories->paginate(10);
		$data['currentpage'] = $request->uri->getSegment(2);
		$data['pager'] = $categories->pager;
		return view('all-categories',$data);
	}

	public function childcategories(){
		$request = \Config\Services::request();
		$session = session();
		$session->set(['currentPage' => $request->uri]);
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$data = array();
		$request = \Config\Services::request();
		$session = session();
		$userid = $session->get('id');
		$categories = new Categories();
		$categories->where('deleted',0);
		$categories->where('parent_id!=',0);
		$pager = \Config\Services::pager();
		$data['categories'] = $categories->paginate(10);
		$data['currentpage'] = $request->uri->getSegment(2);
		$data['pager'] = $categories->pager;
		return view('all-categories',$data);
	}

	public function editcategory($catid){
		$session = session();
		$currentPage = $session->get('currentPage');
		$categories = new Categories();
		$categories1 = new Categories();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$data = array();
		$request = \Config\Services::request();
		$userid = $session->get('id');
		$categories->where('id',$catid);
		$categories1->where('parent_id',0);
		$pager = \Config\Services::pager();
		$data['category'] = $categories->findAll();
		$data['currentpage'] = $request->uri->getSegment(2);
		$data['categories'] = $categories1->findAll();
		return view('edit-categories',$data);
	}
	public function deletecategory($catid){
		$request = \Config\Services::request();
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$categories = new Categories();
		$catData = [
			'id'=>$catid,
			'deleted' => '1',
		];
		$categories->save($catData);
		$session = session();
		$session->setFlashdata('success', 'Category deleted successfully');
		$currentPage = $session->get('currentPage');
		return redirect()->to(base_url($currentPage));
	}
	public function disablecategory($catid){
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$categories = new Categories();
		$userData = [
			'id'=>$catid,
			'valid' => 0,
		];
		$categories->save($userData);
		$session = session();
		$session->setFlashdata('success', 'Category disabled successfully');
		$currentPage = $session->get('currentPage');
		return redirect()->to(base_url($currentPage));
	}

	public function enablecategory($catid){
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$categories = new Categories();
		$userData = [
			'id'=>$catid,
			'valid' => 1,
		];
		$categories->save($userData);
		$session = session();
		$session->setFlashdata('success', 'Category disabled successfully');
		$currentPage = $session->get('currentPage');
		return redirect()->to(base_url($currentPage));
	}
	/*---------------------*/
	/*----------- Plans Start -----------*/

	public function allPlans(){
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$data = array();
		$request = \Config\Services::request();
		$plans = new Plans();
		$plans->where('deleted',0);
		$pager = \Config\Services::pager();
		$cat1 = new Categories();
	    $data['categories'] = $cat1->findAll();
		$data['plans'] = $plans->paginate(6);
		$data['currentpage'] = $request->uri->getSegment(2);
		$data['pager'] = $plans->pager;
		return view('all-plans',$data);
	}
	public function addnewplan(){
		$request = \Config\Services::request();
		$plans = new Plans();
		$plansmeta = new PlansMeta();
		$session = session();
		$name = $this->request->getVar('name');
		$details = $this->request->getVar('details');
		$planData = [
			'plan_name' => $name,
			'created_at' => Time::now(),
			'modified_at' => Time::now(),
			'valid' => 1,
			'deleted' => 0,
		];
		$plans->save($planData);
		$insertedId = $plans->insertID(); 
		if($insertedId){
			foreach ($details as $k1 => $v1) {
				$planMetaData = [
					'plan_id' => $insertedId,
					'plan_duration' => $v1['name'],
					'plan_price' => $v1['price'],
					'created_at' => Time::now(),
					'modified_at' => Time::now(),
					'valid' => 1,
					'deleted' => 0,
				];
				$plansmeta->save($planMetaData);
			}
		}
		return redirect()->to(base_url('/admin/allPlans'));
	}

	public function addplan(){
		$request = \Config\Services::request();
		$cat1 = new Categories();
	    $data['categories'] = $cat1->findAll();
		$data['currentpage'] = $request->uri->getSegment(2);
		return view('add-plan',$data);
	}

	public function updateplan(){
		$request = \Config\Services::request();
		$db = \Config\Database::connect();
		$plansmeta = new PlansMeta();
		$session = session();
		$currentPage = $session->get('currentPage');
		$categories = new Categories();
		$planid = $this->request->getVar('planid');
		$name = $this->request->getVar('name');
		$details = $this->request->getVar('details');
		$idarray=array();
		foreach ($details as $k => $v) {
			$idarray[] = $v['id'];
			$planData = [
				'id'=>$v['id'],
				'plan_duration' => $v['name'],
				'plan_price' => $v['price'],
				'modified_at' => Time::now(),
			];
			$plansmeta->save($planData);
		}
		$idar1 = implode(',',$idarray);
		$db = $db->query("update plans_meta set deleted=1 where plan_id='".$planid."' and id not in (".$idar1.")");
		return redirect()->to(base_url('/admin/allPlans'));
	}

	public function editplan($catid){
		$session = session();
		$plans = new Plans();
		$plansmeta = new PlansMeta();
		$categories = new Categories();
		$categories->where('deleted',0);
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$data = array();
		$request = \Config\Services::request();
		$plans->where('id',$catid);
		$pager = \Config\Services::pager();
		$result = $plans->findAll();
		if(count($result) > 0){
			$plansmeta->where('plan_id',$result[0]['id']);
			$plansmeta->where('deleted',0);
			$metaResult = $plansmeta->findAll();
			$result[0]['meta'] = $metaResult;
		}
		$cat1 = new Categories();
	    $data['categories'] = $cat1->findAll();
		$data['plan'] = $result;
		$data['currentpage'] = $request->uri->getSegment(2);
		$data['categories'] = $categories->findAll();
		return view('edit-plan',$data);
	}

	public function deleteplan($catid){
		$request = \Config\Services::request();
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$plans = new Plans();
		$planData = [
			'id'=>$catid,
			'deleted' => '1',
			'modified_at' => Time::now(),
		];
		$plans->save($planData);
		$session = session();
		$session->setFlashdata('success', 'Plan deleted successfully');
		return redirect()->to(base_url('/admin/allPlans'));
	}
	public function disablelisting($listid){
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$listing = new Listing();
		$listingData = [
			'id'=>$listid,
			'valid' => 0,
			'modified_at' => Time::now(),
		];
		$listing->save($listingData);
		$session = session();
		$session->setFlashdata('success', 'Listing disabled successfully');
		return redirect()->to(base_url('/admin/allads'));
	}
	public function enablelisting($listid){
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$listing = new Listing();
		$listingData = [
			'id'=>$listid,
			'valid' => 1,
			'modified_at' => Time::now(),
		];
		$listing->save($listingData);
		$session = session();
		$session->setFlashdata('success', 'Listing enabled successfully');
		return redirect()->to(base_url('/admin/allads'));
	}

	public function disableplan($planid){
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$plans = new Plans();
		$planData = [
			'id'=>$planid,
			'valid' => 0,
			'modified_at' => Time::now(),
		];
		$plans->save($planData);
		$session = session();
		$session->setFlashdata('success', 'Plan disabled successfully');
		return redirect()->to(base_url('/admin/allPlans'));
	}

	public function enableplan($planid){
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$plans = new Plans();
		$planData = [
			'id'=>$planid,
			'valid' => 1,
			'modified_at' => Time::now(),
		];

		$plans->save($planData);
		$session = session();
		$session->setFlashdata('success', 'Plan enabled successfully');
		return redirect()->to(base_url('/admin/allPlans'));
	}

	/*---------------*/
	/*-------All Attribute Start--------*/
	public function allattributes(){
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$data = array();
		$request = \Config\Services::request();
		$session = session();
		$userid = $session->get('id');
		$attributes = new MainAttributes();
		$categories = new Categories();
		$attributes->where('deleted',0);
		$pager = \Config\Services::pager();
		$result = $attributes->paginate(10);
		foreach ($result as $k1 => $v1) {
			$categories->where('id',$v1['parent_category_id']);
			$cat = $categories->findAll();
			$result[$k1]['parent_category_name'] = $cat[0]['name'];
		}
		$cat1 = new Categories();
	    $data['categories'] = $cat1->findAll();
		$data['attributes'] = $result;
		$data['currentpage'] = $request->uri->getSegment(2);
		$data['pager'] = $attributes->pager;
		return view('all-attributes',$data);
	}
	public function addattributes(){
		$session = session();
		$attributes = new MainAttributes();
		$attributesmeta = new Attributes();
		$categories = new Categories();
		$categories->where('deleted',0);
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$data = array();
		$request = \Config\Services::request();
		$result=array();
		$data['attribute'] = $result;
		$data['currentpage'] = $request->uri->getSegment(2);
		$data['categories'] = $categories->findAll();
		return view('add-attribute',$data);
	}

	public function editattribute($attrid){
		$session = session();
		$attributes = new MainAttributes();
		$attributesmeta = new Attributes();
		$categories = new Categories();
		$categories->where('deleted',0);
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$data = array();
		$request = \Config\Services::request();
		$attributes->where('id',$attrid);
		$pager = \Config\Services::pager();
		$result = $attributes->findAll();
		if(count($result) > 0){
			$attributesmeta->where('parent_attribute_id',$result[0]['id']);
			$attributesmeta->where('deleted',0);
			$metaResult = $attributesmeta->findAll();
			$result[0]['meta'] = $metaResult;
		}
		$data['attribute'] = $result;
		$data['currentpage'] = $request->uri->getSegment(2);
		$data['categories'] = $categories->findAll();
		return view('edit-attribute',$data);
	}

	public function updateAttribute(){
		$request = \Config\Services::request();
		$db = \Config\Database::connect();
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$attributes = new MainAttributes();
		$attributesmeta = new Attributes();
		$categories = new Categories();
		$recievedValues = $this->request->getVar();
		$attrData = [
			'id'=>$recievedValues['attrid'],
			'attribute_name'=>$recievedValues['name'],
			'type'=>$recievedValues['display_type'],
			'attribute_type'=>$recievedValues['attr_type'],
			'parent_category_id'=>$recievedValues['category'],
			'modified_at' => Time::now(),
		];
		$attributes->save($attrData);
		$insertedId = $attributes->insertID(); 
		$idarray=array();
		foreach ($recievedValues['details'] as $k1 => $v1) {
			$idarray[] = $v1['id'];
			$attributesData = [
				'id'=>$v1['id'],
				'option_name' => $v1['name'],
				'parent_attribute_id' => $recievedValues['attrid']?$recievedValues['attrid']:$insertedId,
				'modified_at' => Time::now(),
			];
			$attributesmeta->save($attributesData);
		}
		$idar1 = implode(',',$idarray);
		if($recievedValues['attrid']){
			$db = $db->query("update attribute_options set deleted=1 where parent_attribute_id='".$recievedValues['attrid']."' and id not in (".$idar1.")");
		}
		$session->setFlashdata('success', 'Plan edited successfully');
		return redirect()->to(base_url('/admin/allattributes'));

	}

	public function deleteattribute($attrid){
		$request = \Config\Services::request();
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$attributes = new MainAttributes();
		$attributesData = [
			'id'=>$attrid,
			'deleted' => '1',
			'modified_at' => Time::now(),
		];
		$attributes->save($attributesData);
		$session = session();
		$session->setFlashdata('success', 'Plan deleted successfully');
		return redirect()->to(base_url('/admin/allattributes'));
	}

	public function disableattribute($attrid){
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$attributes = new MainAttributes();
		$attributesData = [
			'id'=>$attrid,
			'valid' => 0,
			'modified_at' => Time::now(),
		];
		$attributes->save($attributesData);
		$session = session();
		$session->setFlashdata('success', 'Attribute disabled successfully');
		return redirect()->to(base_url('/admin/allattributes'));
	}

	public function enableattribute($attrid){
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$attributes = new MainAttributes();
		$attributesData = [
			'id'=>$attrid,
			'valid' => 1,
			'modified_at' => Time::now(),
		];
		$attributes->save($attributesData);
		$session = session();
		$session->setFlashdata('success', 'Attribute enabled successfully');
		return redirect()->to(base_url('/admin/allattributes'));
	}

	/*---------------*/
	/*------User section starts---------*/

	public function allusers(){
		$session = session();
		$db = \Config\Database::connect();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$data = array();
		$request = \Config\Services::request();
		$session = session();
		$userid = $session->get('id');
		$users = new UserModel();
		$cat1 = new Categories();
	    $data['categories'] = $cat1->findAll();
		$users->where('deleted',0);
		$pager = \Config\Services::pager();
		$result = $users->paginate(6);
		foreach ($result as $k4 => $v4) {
			$res = $db->query("SELECT plan_name FROM plans WHERE id IN (SELECT plan_id FROM plans_meta WHERE id IN (SELECT plan_id FROM users_plan_relation WHERE user_id='".$v4['id']."' AND plan_end_date > CURDATE()))");
			$result[$k4]['purchasePlan'] = $res->getResult('array');
		}
		$data['users'] = $result;
		$data['currentpage'] = $request->uri->getSegment(2);
		$data['pager'] = $users->pager;
		
		return view('all-users',$data);
	}
	public function deleteuser($userid){
		$request = \Config\Services::request();
		$session = session();
		$userid1 = $session->get('id');
		if(!$userid1){
			return redirect()->to(base_url('/'));
		}
		$user = new UserModel();
		$userData = [
			'id'=>$userid,
			'deleted' => '1',
			'modified_date' => Time::now(),
		];
		$user->save($userData);
		$session = session();
		$session->setFlashdata('success', 'Plan deleted successfully');
		return redirect()->to(base_url('/admin/allusers'));
	}

	public function disableuser($usrid){
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$user = new UserModel();
		$userData = [
			'id'=>$usrid,
			'valid' => 0,
			'modified_date' => Time::now(),
		];
		$user->save($userData);
		$session = session();
		$session->setFlashdata('success', 'Attribute disabled successfully');
		return redirect()->to(base_url('/admin/allusers'));
	}

	public function enableuser($usrid){
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$user = new UserModel();
		$userData = [
			'id'=>$usrid,
			'valid' => 1,
			'modified_date' => Time::now(),
		];
		$user->save($userData);
		$session = session();
		$session->setFlashdata('success', 'Attribute enabled successfully');
		return redirect()->to(base_url('/admin/allusers'));
	}

	/*---------------------*/


	public function allinvoices(){
		$session = session();
		$db = \Config\Database::connect();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$data = array();
		$request = \Config\Services::request();
		$session = session();
		$userid = $session->get('id');
		$invoice = new Invoice();
		$user = new UserModel();
		$plans = new Plans();
		$cat1 = new Categories();
	    $data['categories'] = $cat1->findAll();
		$invoice->where('deleted',0);
		$pager = \Config\Services::pager();
		$result = $invoice->paginate(6);
		foreach ($result as $key => $value) {
			$res = $db->query("Select email from users where id='".$value['user_id']."'");
			$userresult = $res->getResult('array');
			$result[$key]['email'] = $userresult[0]['email'];
			$res1 = $db->query("Select plan_id,plan_duration from plans_meta where id='".$value['plan_id']."'");
			$planresult = $res1->getResult('array');
			$result[$key]['plan_duration'] = $planresult[0]['plan_duration'];
			$res2 = $db->query("Select plan_name from plans where id='".$planresult[0]['plan_id']."'");
			$planresult1 = $res2->getResult('array');
			$result[$key]['plan_name'] = $planresult1[0]['plan_name'];
		}
		$data['invoice'] = $result;
		$data['currentpage'] = $request->uri->getSegment(2);
		$data['pager'] = $invoice->pager;
		return view('all-invoice',$data);
	}

	public function deleteinvoice($invoiceid){
		$request = \Config\Services::request();
		$session = session();
		$userid1 = $session->get('id');
		if(!$userid1){
			return redirect()->to(base_url('/'));
		}
		$invoice = new Invoice();
		$invoiceData = [
			'id'=>$invoiceid,
			'deleted' => '1',
			'modified_date' => Time::now(),
		];
		$invoice->save($invoiceData);
		$session = session();
		$session->setFlashdata('success', 'Invoice deleted successfully');
		return redirect()->to(base_url('/admin/allinvoices'));
	}

	public function disableinvoice($invoiceid){
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$invoice = new Invoice();
		$invoiceData = [
			'id'=>$invoiceid,
			'valid' => 0,
			'modified_date' => Time::now(),
		];
		$invoice->save($invoiceData);
		$session = session();
		$session->setFlashdata('success', 'Attribute disabled successfully');
		return redirect()->to(base_url('/admin/allinvoices'));
	}

	public function enableinvoice($invoiceid){
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		$invoice = new Invoice();
		$invoiceData = [
			'id'=>$invoiceid,
			'valid' => 1,
			'modified_date' => Time::now(),
		];
		$invoice->save($invoiceData);
		$session = session();
		$session->setFlashdata('success', 'Attribute enabled successfully');
		return redirect()->to(base_url('/admin/allinvoices'));
	}

	public function generateInvoice(){
		$session = session();
		$userid = $session->get('id');
		if(!$userid){
			return redirect()->to(base_url('/'));
		}
		
	}
 public function getPostState()
  {

    $country_id = $_POST['con'];
    $data = [
      'country_id' => $country_id,
      'state_id' => "",
      'city_id' => "",
      'region_id' => ""
    ];
    $db = \Config\Database::connect();
    $statetxt = '<select name="state" id="state-sel"
                      onchange="getCity(this.value); setFooterdata();">
                      <option value="">Select State</option>
                      ';
    $query_state = $db->query("SELECT * FROM states WHERE country_id = " . $country_id . " ORDER BY name ASC");
    foreach ($query_state->getResult() as $row_state) {
      $id = $row_state->id;
      $name = $row_state->name;
      $statetxt .= '<option value="' . $id . '">' . $name . '</option>';
    }
    $statetxt .= " </select>";
    print_r($statetxt);
  }

  public function getPostCity()
  {
    $db = \Config\Database::connect();
    $state_id = $_POST['con'];
    $data = [
      'state_id' => $state_id
    ];

    $citytxt = '<select name="city" id="city-sel"
                      onchange="getRegion(this.value); setFooterdata();">
                      <option value="">Select City</option>
                      ';
    $query_city = $db->query("SELECT * FROM cities WHERE state_id = " . $state_id . " ORDER BY name ASC");
    foreach ($query_city->getResult() as $row_city) {
      $id = $row_city->id;
      $name = $row_city->name;
      $citytxt .= '<option value="' . $id . '">' . $name . '</option>';
    }
    $citytxt .= " </select>";
    print_r($citytxt);
  }
  public function getPostRegion()
  {
    $db = \Config\Database::connect();
    $city_id = $_POST['con'];
    $data = [
      'city_id' => $city_id
    ];

    $regiontxt = '<select name="region" id="region-sel"
                      onchange="setRegion(this.value);">
                      <option value="">Select Region</option>
                      ';
    $query_city = $db->query("SELECT * FROM region WHERE city_id = " . $city_id . " ORDER BY name ASC");
    foreach ($query_city->getResult() as $row_city) {
      $id = $row_city->id;
      $name = $row_city->name;
      $regiontxt .= '<option value="' . $id . '">' . $name . '</option>';
    }
    $regiontxt .= " </select>";
    print_r($regiontxt);
  }
  function submitPost(){
  	print_r($_POST);

  	$category = $_POST['category'];
    $subcategory = $_POST['subcategory'];
    $title = $_POST['title'];
    $desc = $_POST['desc'];
    $name = $_POST['name'];
    $name = $_POST['name'];
    $name = $_POST['name'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $country = $_POST['country'];
    $state = $_POST['state'];
    $city = $_POST['city'];
    $region = $_POST['region'];
    $zipcode = $_POST['zipcode'];
    $keywords = $_POST['keywords'];
    /*
    [duration] => Array
        (
            [0] => 0
            [1] => 100
            [2] => 10
            [3] => 40
            [4] => 70
        )

    [package] => Array
        (
            [0] => 3
        )

    [metadesc] => Meta Description
    */
  }
}