<?php

namespace App\Controllers;

use App\Models\Categories;
use CodeIgniter\Config\Config;
use CodeIgniter\Controller;

class Home extends BaseController
{
	public function index()
   {
      $session = \Config\Services::session();
      $message = $session->getFlashdata('message');
	  $cat = new Categories();
	  $data = $cat->findAll();
	  $catArray = array();
	  foreach ($data as $key => $value){
		  if($value['parent_id']==0){
			$catArray[] = $value; 
		  }
	  }
     
     foreach ($catArray as $k => $v) {
        //print_r($v['id']);
        foreach ($data as $key => $value1){
         if($v['id']==$value1['parent_id']){
          $catArray[$k]['subCategory'][] = $value1; 
         }else{
            $catArray[$k]['subCategory'][] = array(); 
         }
      }
    }

    $data['categories'] = $catArray;
    $pager = \Config\Services::pager();
    $data['message'] = $message;
    echo view('home', $data);
  }
  public function search()
  {
    if ($this->request->getMethod() == 'post') {
      echo $this->request->getVar('keyword');
    }
  }
  public function country()
  {
    $db = \Config\Database::connect();


    $countrytxt = '<select name="country" id="country-sel"
                      onchange="getState(this.value); setFooterdata(); getCountry(this.value);get_state_modal(this.value)">
                      <option value="">Select</option>
                      <option value="101" onclick="get_state_modal(this.value)">India</option>
                      ';
    $query_country = $db->query("SELECT * FROM countries ORDER BY name ASC");
    foreach ($query_country->getResult() as $row_country) {
      $id = $row_country->id;
      $name = $row_country->name;
      $selected  = "";
      if (session()->get("country_id") == $id) {
        $selected = "selected";
      }

      $countrytxt .= '<option value="' . $id . '" ' . $selected . '>' . $name . '</option>';
    }
    $countrytxt .= " </select>";
    print_r($countrytxt);
  }
  public function getState()
  {
    // unset($_SESSION['state']);
    // unset($_SESSION['city']);
    // unset($_SESSION['region']);

    $country_id = $_POST['con'];
    $data = [
      'country_id' => $country_id,
      'state_id' => "",
      'city_id' => "",
      'region_id' => ""
    ];
    session()->set($data);
    $db = \Config\Database::connect();
    $statetxt = '<select name="state" id="state-sel"
                      onchange="getCity(this.value); setFooterdata();">
                      <option value="">Select State</option>
                      ';
    $query_state = $db->query("SELECT * FROM states WHERE country_id = " . $country_id . " ORDER BY name ASC");
    foreach ($query_state->getResult() as $row_state) {
      $id = $row_state->id;
      $name = $row_state->name;
      $statetxt .= '<option value="' . $id . '">' . $name . '</option>';
    }
    $statetxt .= " </select>";
    print_r($statetxt);
  }

  public function getCity()
  {
    $db = \Config\Database::connect();
    $state_id = $_POST['con'];
    $data = [
      'state_id' => $state_id
    ];
    session()->set($data);

    $citytxt = '<select name="city" id="city-sel"
                      onchange="getRegion(this.value); setFooterdata();">
                      <option value="">Select City</option>
                      ';
    $query_city = $db->query("SELECT * FROM cities WHERE state_id = " . $state_id . " ORDER BY name ASC");
    foreach ($query_city->getResult() as $row_city) {
      $id = $row_city->id;
      $name = $row_city->name;
      $citytxt .= '<option value="' . $id . '">' . $name . '</option>';
    }
    $citytxt .= " </select>";
    print_r($citytxt);
  }
  public function getRegion()
  {
    $db = \Config\Database::connect();
    $city_id = $_POST['con'];
    $data = [
      'city_id' => $city_id
    ];
    session()->set($data);

    $regiontxt = '<select name="region" id="region-sel"
                      onchange="setRegion(this.value);">
                      <option value="">Select Region</option>
                      ';
    $query_city = $db->query("SELECT * FROM region WHERE city_id = " . $city_id . " ORDER BY name ASC");
    foreach ($query_city->getResult() as $row_city) {
      $id = $row_city->id;
      $name = $row_city->name;
      $regiontxt .= '<option value="' . $id . '">' . $name . '</option>';
    }
    $regiontxt .= " </select>";
    print_r($regiontxt);
  }
  public function setFooterData()
  {
    $db = \Config\Database::connect();

    $country_id = session()->get("country_id");
    if ($country_id != "") {

      $dataArray = array();
      $stateArray = array();
      $query_state = $db->query("SELECT * FROM states WHERE country_id = " . $country_id . " ORDER BY name ASC");
      foreach ($query_state->getResult() as $row_state) {
        $temp = array();
        $temp['id'] = $row_state->id;
        $temp['name'] = $row_state->name;
        array_push($stateArray, $temp);
      }
      $dataArray['state'] = $stateArray;

      $state_id = session()->get("state_id");
      if ($state_id != "") {

        $cityArray = array();
        $query_city = $db->query("SELECT * FROM cities WHERE state_id = " . $state_id . " ORDER BY name ASC");
        foreach ($query_city->getResult() as $row_city) {
          $temp = array();
          $temp['id'] = $row_city->id;
          $temp['name'] = $row_city->name;
          array_push($cityArray, $temp);
        }
        $dataArray['city'] = $cityArray;

        $city_id = session()->get("city_id");
      if ($city_id != "") {

        $regionArray = array();
        $query_region = $db->query("SELECT * FROM region WHERE city_id = " . $city_id . " ORDER BY name ASC");
        foreach ($query_region->getResult() as $row_region) {
          $temp = array();
          $temp['id'] = $row_region->id;
          $temp['name'] = $row_region->name;
          array_push($regionArray, $temp);
        }
        $dataArray['region'] = $regionArray;
      }
      }
      print_r(json_encode($dataArray));
    }
  }

  public function setRegion()
  {
    $region_id = $_POST['con'];
    $data = [
      'region_id' => $region_id
    ];
    session()->set($data);

    print_r($_POST['con']);
  }
  public function setCity()
  {
    $city_id = $_POST['con'];
    $data = [
      'city_id' => $city_id,
      'region_id' => ""
    ];
    session()->set($data);

    print_r($_POST['con']);
  }
  public function setState()
  {
    $state_id = $_POST['con'];
    $data = [
      'state_id' => $state_id,
      'city_id' => "",
      'region_id' => ""
    ];
    session()->set($data);

    print_r($_POST['con']);
  }
}
